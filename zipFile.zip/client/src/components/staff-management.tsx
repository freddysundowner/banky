import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { getErrorMessage } from "@/lib/error-utils";
import { Users, Plus, Pencil, Trash2, Mail, Phone, Lock, Unlock, KeyRound, UserX, UserCheck, MoreHorizontal } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import type { Staff, Branch } from "@shared/tenant-types";
import { useResourcePermissions, RESOURCES } from "@/hooks/use-resource-permissions";
import AddStaffPage from "@/pages/add-staff";

interface StaffManagementProps {
  organizationId: string;
}

interface RoleData {
  id: string;
  name: string;
  description: string;
  is_system: boolean;
  permissions: string[];
}

const staffCreateSchema = z.object({
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().min(1, "Last name is required"),
  username: z.string().min(1, "Username is required").regex(/^[a-zA-Z0-9._-]+$/, "Username can only contain letters, numbers, dots, underscores, and hyphens"),
  secondary_email: z.string().email("Valid email is required").optional().or(z.literal("")),
  phone: z.string().optional(),
  password: z.string().min(6, "Password is required (min 6 characters)"),
  role: z.string().default("staff"),
  branch_id: z.string().optional(),
  national_id: z.string().min(1, "National ID is required"),
  date_of_birth: z.string().min(1, "Date of birth is required"),
  gender: z.string().optional(),
  next_of_kin_name: z.string().optional(),
  next_of_kin_phone: z.string().optional(),
  next_of_kin_relationship: z.string().optional(),
});

const staffUpdateSchema = z.object({
  first_name: z.string().min(1, "First name is required"),
  last_name: z.string().min(1, "Last name is required"),
  email: z.string().email("Valid email is required"),
  secondary_email: z.string().email("Valid email is required").optional().or(z.literal("")),
  phone: z.string().optional(),
  role: z.string().default("staff"),
  branch_id: z.string().optional(),
  national_id: z.string().optional(),
  date_of_birth: z.string().optional(),
  gender: z.string().optional(),
  next_of_kin_name: z.string().optional(),
  next_of_kin_phone: z.string().optional(),
  next_of_kin_relationship: z.string().optional(),
});

type StaffCreateData = z.infer<typeof staffCreateSchema>;
type StaffUpdateData = z.infer<typeof staffUpdateSchema>;
type StaffFormData = StaffCreateData | StaffUpdateData;

export default function StaffManagement({ organizationId }: StaffManagementProps) {
  const { toast } = useToast();
  const { user } = useAuth();
  const [showDialog, setShowDialog] = useState(false);
  const [showAddPage, setShowAddPage] = useState(false);
  const [editing, setEditing] = useState<Staff | null>(null);
  const [deleting, setDeleting] = useState<Staff | null>(null);
  const [resettingPassword, setResettingPassword] = useState<Staff | null>(null);
  const [newPassword, setNewPassword] = useState("");
  const { canWrite } = useResourcePermissions(organizationId, RESOURCES.STAFF);

  // Determine if user can see multiple branches (admin/owner have no branch restriction)
  const userBranchId = (user as any)?.branchId;
  const userRole = (user as any)?.role;
  const canSeeAllBranches = !userBranchId || userRole === 'admin' || userRole === 'owner';

  const { data: staffList, isLoading } = useQuery<Staff[]>({
    queryKey: ["/api/organizations", organizationId, "staff"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/staff`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch staff");
      return res.json();
    },
  });

  const { data: branches } = useQuery<Branch[]>({
    queryKey: ["/api/organizations", organizationId, "branches"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/branches`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch branches");
      return res.json();
    },
  });

  const { data: roles } = useQuery<RoleData[]>({
    queryKey: ["/api/organizations", organizationId, "roles"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/roles`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch roles");
      return res.json();
    },
  });

  const { data: organization } = useQuery<{ id: string; name: string }>({
    queryKey: ["/api/organizations", organizationId],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch organization");
      return res.json();
    },
  });

  // Generate domain from organization name (remove special chars, lowercase)
  const orgDomain = organization?.name?.toLowerCase().replace(/[^a-z0-9]/g, '') || 'organization';

  const form = useForm<StaffFormData>({
    resolver: zodResolver(staffCreateSchema),
    defaultValues: {
      first_name: "",
      last_name: "",
      username: "",
      secondary_email: "",
      phone: "",
      password: "",
      role: "staff",
      branch_id: undefined,
      national_id: "",
      date_of_birth: "",
      gender: "",
      next_of_kin_name: "",
      next_of_kin_phone: "",
      next_of_kin_relationship: "",
    },
  });

  useEffect(() => {
    if (branches && branches.length === 1 && !form.getValues("branch_id")) {
      form.setValue("branch_id", branches[0].id);
    }
  }, [branches, form]);

  // Dynamically update resolver when switching between create/edit modes
  useEffect(() => {
    if (editing) {
      form.clearErrors();
    }
  }, [editing]);

  const createMutation = useMutation({
    mutationFn: async (data: StaffFormData) => {
      // Auto-assign branch for restricted users
      const submitData = { ...data };
      if (!canSeeAllBranches && userBranchId) {
        submitData.branch_id = userBranchId;
      }
      // Validate branch is selected for admins
      if (canSeeAllBranches && !submitData.branch_id) {
        throw new Error("Please select a branch");
      }
      return apiRequest("POST", `/api/organizations/${organizationId}/staff`, submitData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      setShowDialog(false);
      form.reset();
      toast({ title: "Staff member created successfully" });
    },
    onError: (error) => {
      toast({ title: error.message || "Failed to create staff member", variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async (data: StaffFormData) => {
      if (!editing) return;
      return apiRequest("PATCH", `/api/organizations/${organizationId}/staff/${editing.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      setShowDialog(false);
      setEditing(null);
      form.reset();
      toast({ title: "Staff member updated successfully" });
    },
    onError: () => {
      toast({ title: "Failed to update staff member", variant: "destructive" });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      if (!deleting) return;
      return apiRequest("DELETE", `/api/organizations/${organizationId}/staff/${deleting.id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      setDeleting(null);
      toast({ title: "Staff member deleted successfully" });
    },
    onError: (error: unknown) => {
      setDeleting(null);
      toast({ 
        title: "Cannot delete staff", 
        description: getErrorMessage(error),
        variant: "destructive" 
      });
    },
  });

  const lockMutation = useMutation({
    mutationFn: async (staffId: string) => {
      return apiRequest("PUT", `/api/organizations/${organizationId}/hr/staff/${staffId}/lock`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      toast({ title: "Staff account locked" });
    },
    onError: () => {
      toast({ title: "Failed to lock account", variant: "destructive" });
    },
  });

  const unlockMutation = useMutation({
    mutationFn: async (staffId: string) => {
      return apiRequest("PUT", `/api/organizations/${organizationId}/hr/staff/${staffId}/unlock`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      toast({ title: "Staff account unlocked" });
    },
    onError: () => {
      toast({ title: "Failed to unlock account", variant: "destructive" });
    },
  });

  const activateMutation = useMutation({
    mutationFn: async (staffId: string) => {
      return apiRequest("PUT", `/api/organizations/${organizationId}/hr/staff/${staffId}/activate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      toast({ title: "Staff activated" });
    },
    onError: () => {
      toast({ title: "Failed to activate staff", variant: "destructive" });
    },
  });

  const deactivateMutation = useMutation({
    mutationFn: async (staffId: string) => {
      return apiRequest("PUT", `/api/organizations/${organizationId}/hr/staff/${staffId}/deactivate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      toast({ title: "Staff deactivated" });
    },
    onError: () => {
      toast({ title: "Failed to deactivate staff", variant: "destructive" });
    },
  });

  const resetPasswordMutation = useMutation({
    mutationFn: async () => {
      if (!resettingPassword) return;
      return apiRequest("PUT", `/api/organizations/${organizationId}/hr/staff/${resettingPassword.id}/reset-password`, { new_password: newPassword });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "staff"] });
      setResettingPassword(null);
      setNewPassword("");
      toast({ title: "Password reset successfully" });
    },
    onError: () => {
      toast({ title: "Failed to reset password", variant: "destructive" });
    },
  });

  // Early return for Add Staff page (must be after all hooks)
  if (showAddPage) {
    return <AddStaffPage organizationId={organizationId} onBack={() => setShowAddPage(false)} />;
  }

  const openEditDialog = (staff: Staff) => {
    setEditing(staff);
    const staffWithProfile = staff as Staff & { profile?: any };
    form.reset({
      first_name: staff.first_name,
      last_name: staff.last_name,
      secondary_email: staff.secondary_email || "",
      phone: staff.phone || "",
      role: staff.role as any,
      branch_id: staff.branch_id || undefined,
      national_id: staffWithProfile.profile?.national_id || "",
      date_of_birth: staffWithProfile.profile?.date_of_birth || "",
      gender: staffWithProfile.profile?.gender || "",
      next_of_kin_name: staffWithProfile.profile?.next_of_kin_name || "",
      next_of_kin_phone: staffWithProfile.profile?.next_of_kin_phone || "",
      next_of_kin_relationship: staffWithProfile.profile?.next_of_kin_relationship || "",
    } as any);
    setShowDialog(true);
  };

  const handleSubmit = (data: StaffFormData) => {
    if (editing) {
      updateMutation.mutate(data);
    } else {
      createMutation.mutate(data);
    }
  };

  // Manual submit for editing mode (bypasses password validation)
  const handleEditSubmit = () => {
    if (!editing) return;
    const values = form.getValues();
    // Validate edit fields manually
    if (!values.first_name || !values.last_name) {
      form.setError("first_name", { message: "First name is required" });
      return;
    }
    updateMutation.mutate(values);
  };

  const getRoleBadgeVariant = (role: string) => {
    switch (role) {
      case "admin": return "destructive";
      case "manager": return "default";
      case "loan_officer": return "secondary";
      default: return "outline";
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="min-w-0">
          <h1 className="text-2xl font-bold">Staff Management</h1>
          <p className="text-muted-foreground">Manage your organization's staff members</p>
        </div>
        {canWrite && (
          <Button onClick={() => setShowAddPage(true)} data-testid="button-add-staff" className="shrink-0">
            <Plus className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Add Staff</span>
            <span className="sm:hidden">Add</span>
          </Button>
        )}
      </div>

      <Card>
        <CardContent className="pt-6">
          {isLoading ? (
            <div className="space-y-3">
              <Skeleton className="h-12 w-full" />
              <Skeleton className="h-12 w-full" />
            </div>
          ) : staffList && staffList.length > 0 ? (
            <div className="overflow-x-auto -mx-6 px-6">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead className="hidden sm:table-cell">Employee #</TableHead>
                  <TableHead className="hidden md:table-cell">Contact</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead className="hidden lg:table-cell">Branch</TableHead>
                  <TableHead className="hidden sm:table-cell">Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {staffList.map((staff) => (
                  <TableRow key={staff.id} data-testid={`row-staff-${staff.id}`}>
                    <TableCell className="font-medium">
                      <div>{staff.first_name} {staff.last_name}</div>
                      <div className="text-sm text-muted-foreground sm:hidden">{staff.staff_number || ""}</div>
                    </TableCell>
                    <TableCell className="hidden sm:table-cell">{staff.staff_number || "-"}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1 text-sm">
                          <Mail className="h-3 w-3" />
                          {staff.email}
                        </div>
                        {staff.phone && (
                          <div className="flex items-center gap-1 text-sm text-muted-foreground">
                            <Phone className="h-3 w-3" />
                            {staff.phone}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant={getRoleBadgeVariant(staff.role)}>
                        {staff.role.replace("_", " ")}
                      </Badge>
                    </TableCell>
                    <TableCell className="hidden lg:table-cell">{(staff as any).branch_name || "-"}</TableCell>
                    <TableCell className="hidden sm:table-cell">
                      <Badge variant={staff.is_active ? "default" : "secondary"}>
                        {staff.is_active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        {canWrite && (
                          <Button variant="ghost" size="icon" onClick={() => openEditDialog(staff)} data-testid={`button-edit-staff-${staff.id}`}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                        )}
                        {canWrite && (
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => setResettingPassword(staff)}>
                                <KeyRound className="mr-2 h-4 w-4" />
                                Reset Password
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              {(staff as any).is_locked ? (
                                <DropdownMenuItem onClick={() => unlockMutation.mutate(staff.id)}>
                                  <Unlock className="mr-2 h-4 w-4" />
                                  Unlock Account
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem onClick={() => lockMutation.mutate(staff.id)}>
                                  <Lock className="mr-2 h-4 w-4" />
                                  Lock Account
                                </DropdownMenuItem>
                              )}
                              {staff.is_active ? (
                                <DropdownMenuItem onClick={() => deactivateMutation.mutate(staff.id)}>
                                  <UserX className="mr-2 h-4 w-4" />
                                  Deactivate
                                </DropdownMenuItem>
                              ) : (
                                <DropdownMenuItem onClick={() => activateMutation.mutate(staff.id)}>
                                  <UserCheck className="mr-2 h-4 w-4" />
                                  Activate
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuSeparator />
                              <DropdownMenuItem onClick={() => setDeleting(staff)} className="text-destructive">
                                <Trash2 className="mr-2 h-4 w-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        )}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <Users className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="font-medium">No staff members yet</h3>
              <p className="text-sm text-muted-foreground mb-4">Add your first staff member to get started</p>
              {canWrite && (
                <Button onClick={() => setShowAddPage(true)} data-testid="button-add-first-staff">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Staff
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={showDialog || !!editing} onOpenChange={(open) => {
        if (!open) { setShowDialog(false); setEditing(null); form.reset(); }
      }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editing ? "Edit Staff Member" : "Add New Staff Member"}</DialogTitle>
            <DialogDescription>
              {editing ? "Update staff member details" : "Add a new staff member to your organization"}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={editing ? (e) => { e.preventDefault(); handleEditSubmit(); } : form.handleSubmit(handleSubmit)} className="space-y-4">
              <div className="grid gap-4 sm:grid-cols-2">
                <FormField control={form.control} name="first_name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name</FormLabel>
                    <FormControl><Input {...field} data-testid="input-staff-first-name" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
                <FormField control={form.control} name="last_name" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name</FormLabel>
                    <FormControl><Input {...field} data-testid="input-staff-last-name" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <div className="grid gap-4 sm:grid-cols-2">
                {!editing ? (
                  <FormField control={form.control} name="username" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email</FormLabel>
                      <FormControl>
                        <div className="flex">
                          <Input {...field} placeholder="username" className="rounded-r-none" data-testid="input-staff-username" />
                          <span className="inline-flex items-center px-3 bg-muted border border-l-0 border-input rounded-r-md text-sm text-muted-foreground">
                            @{orgDomain}.com
                          </span>
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                ) : (
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Email</label>
                    <Input value={editing?.email || ""} disabled className="bg-muted" data-testid="input-staff-email" />
                  </div>
                )}
                <FormField control={form.control} name="phone" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone</FormLabel>
                    <FormControl><Input {...field} data-testid="input-staff-phone" /></FormControl>
                    <FormMessage />
                  </FormItem>
                )} />
              </div>
              <FormField control={form.control} name="secondary_email" render={({ field }) => (
                <FormItem>
                  <FormLabel>Secondary Email (Optional)</FormLabel>
                  <FormControl><Input {...field} type="email" placeholder="Personal email for payslip CC" data-testid="input-staff-secondary-email" /></FormControl>
                  <FormDescription>Payslip emails will be CC'd to this address</FormDescription>
                  <FormMessage />
                </FormItem>
              )} />
              {!editing && (
                <FormField control={form.control} name="password" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Login Password</FormLabel>
                    <FormControl><Input {...field} type="password" placeholder="Min 6 characters" data-testid="input-staff-password" /></FormControl>
                    <FormDescription>This password allows the staff member to log into the system</FormDescription>
                    <FormMessage />
                  </FormItem>
                )} />
              )}
              
              <div className="border-t pt-4 mt-4">
                <h4 className="text-sm font-medium mb-3">Personal Information</h4>
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField control={form.control} name="national_id" render={({ field }) => (
                    <FormItem>
                      <FormLabel>National ID Number {!editing && <span className="text-destructive">*</span>}</FormLabel>
                      <FormControl><Input {...field} placeholder="e.g., 12345678" /></FormControl>
                      <FormDescription>Used as payslip PDF password</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="date_of_birth" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Date of Birth {!editing && <span className="text-destructive">*</span>}</FormLabel>
                      <FormControl><Input {...field} type="date" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
                <div className="grid gap-4 sm:grid-cols-2 mt-4">
                  <FormField control={form.control} name="gender" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Gender</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </div>

              <div className="border-t pt-4 mt-4">
                <h4 className="text-sm font-medium mb-3">Next of Kin</h4>
                <div className="grid gap-4 sm:grid-cols-2">
                  <FormField control={form.control} name="next_of_kin_name" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Full Name</FormLabel>
                      <FormControl><Input {...field} placeholder="Next of kin name" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                  <FormField control={form.control} name="next_of_kin_phone" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl><Input {...field} placeholder="Phone number" /></FormControl>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
                <div className="grid gap-4 sm:grid-cols-2 mt-4">
                  <FormField control={form.control} name="next_of_kin_relationship" render={({ field }) => (
                    <FormItem>
                      <FormLabel>Relationship</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value || ""}>
                        <FormControl>
                          <SelectTrigger><SelectValue placeholder="Select relationship" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="spouse">Spouse</SelectItem>
                          <SelectItem value="parent">Parent</SelectItem>
                          <SelectItem value="sibling">Sibling</SelectItem>
                          <SelectItem value="child">Child</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )} />
                </div>
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <FormField control={form.control} name="role" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Role</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-staff-role"><SelectValue /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(roles || []).map((role) => (
                          <SelectItem key={role.name} value={role.name}>
                            {role.name.replace(/_/g, " ").replace(/\b\w/g, c => c.toUpperCase())}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )} />
                {!(branches && branches.length === 1) && (
                <FormField control={form.control} name="branch_id" render={({ field }) => (
                  <FormItem>
                    <FormLabel>Branch {canSeeAllBranches && <span className="text-destructive">*</span>}</FormLabel>
                    {canSeeAllBranches ? (
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-staff-branch"><SelectValue placeholder="Select branch (required)" /></SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {branches?.map((branch) => (
                            <SelectItem key={branch.id} value={branch.id}>{branch.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : (
                      <div className="text-sm text-muted-foreground p-2 bg-muted rounded">
                        {branches?.find(b => b.id === userBranchId)?.name || "Your assigned branch"}
                      </div>
                    )}
                    <FormMessage />
                  </FormItem>
                )} />
                )}
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => { setShowDialog(false); setEditing(null); form.reset(); }}>Cancel</Button>
                <Button type="submit" disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-staff">
                  {createMutation.isPending || updateMutation.isPending ? "Saving..." : "Save"}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleting} onOpenChange={(open) => !open && setDeleting(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Staff Member</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{deleting?.first_name} {deleting?.last_name}"? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleting(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => deleteMutation.mutate()} disabled={deleteMutation.isPending} data-testid="button-confirm-delete-staff">
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!resettingPassword} onOpenChange={(open) => { if (!open) { setResettingPassword(null); setNewPassword(""); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reset Password</DialogTitle>
            <DialogDescription>
              Set a new password for {resettingPassword?.first_name} {resettingPassword?.last_name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">New Password</label>
              <Input
                type="password"
                placeholder="Enter new password (min 6 characters)"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setResettingPassword(null); setNewPassword(""); }}>Cancel</Button>
            <Button onClick={() => resetPasswordMutation.mutate()} disabled={newPassword.length < 6 || resetPasswordMutation.isPending}>
              {resetPasswordMutation.isPending ? "Resetting..." : "Reset Password"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
