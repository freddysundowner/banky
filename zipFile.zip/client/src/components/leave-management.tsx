import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Calendar, Check, X, Clock, Plus, Search, Users, Building2 } from "lucide-react";
import { useResourcePermissions, RESOURCES } from "@/hooks/use-resource-permissions";

interface LeaveManagementProps {
  organizationId: string;
}

interface Branch {
  id: string;
  name: string;
  code: string;
}

interface Staff {
  id: string;
  staff_number: string;
  first_name: string;
  last_name: string;
  email: string;
  role: string;
  branch_id?: string;
}

interface LeaveRequest {
  id: string;
  staff_id: string;
  leave_type_id: string;
  start_date: string;
  end_date: string;
  days_requested: number;
  reason?: string;
  status: string;
  staff_name?: string;
  leave_type_name?: string;
  approved_by_name?: string;
  created_at: string;
  branch_id?: string;
}

interface LeaveType {
  id: string;
  name: string;
  code: string;
  days_per_year: number;
  is_paid: boolean;
}

interface LeaveBalance {
  id: string;
  staff_id: string;
  leave_type_id: string;
  year: number;
  entitled_days: number;
  used_days: number;
  remaining_days: number;
  staff_name?: string;
  leave_type_name?: string;
  branch_id?: string;
}

export default function LeaveManagement({ organizationId }: LeaveManagementProps) {
  const { toast } = useToast();
  const { hasPermission } = useResourcePermissions(organizationId, RESOURCES.LEAVE);
  const canRead = hasPermission("leave:read");
  const canWrite = hasPermission("leave:write");
  const canApprove = hasPermission("leave:approve");
  
  const [activeTab, setActiveTab] = useState("requests");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [branchFilter, setBranchFilter] = useState<string>("all");
  const [staffSearch, setStaffSearch] = useState("");
  const [showLeaveDialog, setShowLeaveDialog] = useState(false);
  const [leaveForm, setLeaveForm] = useState({
    staff_id: "",
    leave_type_id: "",
    start_date: "",
    end_date: "",
    days_requested: "",
    reason: "",
  });

  const { data: branches } = useQuery<Branch[]>({
    queryKey: ["/api/organizations", organizationId, "branches"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/branches`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch branches");
      return res.json();
    },
  });

  useEffect(() => {
    if (branches && branches.length === 1) {
      setBranchFilter(branches[0].id);
    }
  }, [branches]);

  const { data: staffList } = useQuery<Staff[]>({
    queryKey: ["/api/organizations", organizationId, "hr", "staff"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/hr/staff`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch staff");
      return res.json();
    },
  });

  const { data: leaveRequests, isLoading: loadingRequests } = useQuery<LeaveRequest[]>({
    queryKey: ["/api/organizations", organizationId, "hr", "leave-requests"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/hr/leave-requests`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leave requests");
      return res.json();
    },
  });

  const { data: leaveTypes } = useQuery<LeaveType[]>({
    queryKey: ["/api/organizations", organizationId, "hr", "leave-types"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/hr/leave-types`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leave types");
      return res.json();
    },
  });

  const { data: leaveBalances } = useQuery<LeaveBalance[]>({
    queryKey: ["/api/organizations", organizationId, "hr", "leave-balances"],
    queryFn: async () => {
      const res = await fetch(`/api/organizations/${organizationId}/hr/leave-balances`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch leave balances");
      return res.json();
    },
  });

  const createLeaveRequest = useMutation({
    mutationFn: async () => {
      const payload = {
        ...leaveForm,
        days_requested: parseFloat(leaveForm.days_requested) || 0,
      };
      await apiRequest("POST", `/api/organizations/${organizationId}/hr/leave-requests`, payload);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "hr", "leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "hr", "leave-balances"] });
      setShowLeaveDialog(false);
      setLeaveForm({ staff_id: "", leave_type_id: "", start_date: "", end_date: "", days_requested: "", reason: "" });
      toast({ title: "Success", description: "Leave request submitted" });
    },
    onError: (error: any) => {
      toast({ title: "Error", description: error.message || "Failed to submit leave request", variant: "destructive" });
    },
  });

  const approveLeave = useMutation({
    mutationFn: async (requestId: string) => {
      await apiRequest("PUT", `/api/organizations/${organizationId}/hr/leave-requests/${requestId}/approve`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "hr", "leave-requests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "hr", "leave-balances"] });
      toast({ title: "Success", description: "Leave request approved" });
    },
  });

  const rejectLeave = useMutation({
    mutationFn: async (requestId: string) => {
      await apiRequest("PUT", `/api/organizations/${organizationId}/hr/leave-requests/${requestId}/reject`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "hr", "leave-requests"] });
      toast({ title: "Success", description: "Leave request rejected" });
    },
  });

  const calculateDays = (start: string, end: string) => {
    if (!start || !end) return 0;
    const startDate = new Date(start);
    const endDate = new Date(end);
    const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
    return diffDays;
  };

  const handleDateChange = (field: "start_date" | "end_date", value: string) => {
    const newForm = { ...leaveForm, [field]: value };
    if (newForm.start_date && newForm.end_date) {
      newForm.days_requested = calculateDays(newForm.start_date, newForm.end_date).toString();
    }
    setLeaveForm(newForm);
  };

  const getStaffBranchId = (staffId: string) => {
    return staffList?.find(s => s.id === staffId)?.branch_id;
  };

  const filteredRequests = leaveRequests?.filter(r => {
    if (statusFilter !== "all" && r.status !== statusFilter) return false;
    if (branchFilter !== "all") {
      const staffBranchId = getStaffBranchId(r.staff_id);
      if (staffBranchId !== branchFilter) return false;
    }
    return true;
  }) || [];

  const filteredBalances = leaveBalances?.filter(b => {
    if (branchFilter !== "all") {
      const staffBranchId = getStaffBranchId(b.staff_id);
      if (staffBranchId !== branchFilter) return false;
    }
    if (staffSearch) {
      const searchLower = staffSearch.toLowerCase();
      return b.staff_name?.toLowerCase().includes(searchLower);
    }
    return true;
  }) || [];

  const filteredStaff = staffList?.filter(s => {
    if (branchFilter !== "all" && s.branch_id !== branchFilter) return false;
    return true;
  }) || [];

  const pendingCount = filteredRequests.filter(r => r.status === "pending").length;
  const approvedCount = filteredRequests.filter(r => r.status === "approved").length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200"><Clock className="h-3 w-3 mr-1" />Pending</Badge>;
      case "approved":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200"><Check className="h-3 w-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200"><X className="h-3 w-3 mr-1" />Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  if (!canRead) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          You don't have permission to view leave requests.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Leave Management</h1>
          <p className="text-muted-foreground">Review, approve, and manage staff leave requests</p>
        </div>
        <div className="flex gap-2">
          {branches && branches.length > 1 && (
            <Select value={branchFilter} onValueChange={setBranchFilter}>
              <SelectTrigger className="w-[180px]">
                <Building2 className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by branch" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Branches</SelectItem>
                {branches?.map((branch) => (
                  <SelectItem key={branch.id} value={branch.id}>{branch.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {canWrite && (
            <Button onClick={() => setShowLeaveDialog(true)} className="gap-2">
              <Plus className="h-4 w-4" /> Request Leave
            </Button>
          )}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Pending Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{pendingCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Approved</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{approvedCount}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Leave Types</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{leaveTypes?.length || 0}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Staff with Balances</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{new Set(leaveBalances?.map(b => b.staff_id)).size || 0}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="requests" className="gap-2">
            <Calendar className="h-4 w-4" /> Leave Requests
          </TabsTrigger>
          <TabsTrigger value="balances" className="gap-2">
            <Users className="h-4 w-4" /> Leave Balances
          </TabsTrigger>
        </TabsList>

        <TabsContent value="requests" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Leave Requests</CardTitle>
                  <CardDescription>View and manage staff leave requests</CardDescription>
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[150px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardHeader>
            <CardContent>
              {loadingRequests ? (
                <div className="space-y-3">
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                  <Skeleton className="h-12 w-full" />
                </div>
              ) : filteredRequests.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Staff</TableHead>
                        <TableHead>Leave Type</TableHead>
                        <TableHead>Dates</TableHead>
                        <TableHead>Days</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredRequests.map((request) => (
                        <TableRow key={request.id}>
                          <TableCell className="font-medium">{request.staff_name || "Unknown"}</TableCell>
                          <TableCell>{request.leave_type_name || "Leave"}</TableCell>
                          <TableCell>
                            {new Date(request.start_date).toLocaleDateString()} - {new Date(request.end_date).toLocaleDateString()}
                          </TableCell>
                          <TableCell>{request.days_requested}</TableCell>
                          <TableCell>{getStatusBadge(request.status)}</TableCell>
                          <TableCell className="text-right">
                            {request.status === "pending" && canApprove && (
                              <div className="flex justify-end gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-green-600 hover:text-green-700 hover:bg-green-50"
                                  onClick={() => approveLeave.mutate(request.id)}
                                  disabled={approveLeave.isPending}
                                >
                                  <Check className="h-4 w-4 mr-1" /> Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => rejectLeave.mutate(request.id)}
                                  disabled={rejectLeave.isPending}
                                >
                                  <X className="h-4 w-4 mr-1" /> Reject
                                </Button>
                              </div>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Calendar className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold text-lg">No Leave Requests</h3>
                  <p className="text-muted-foreground mt-1">Staff leave requests will appear here when submitted</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="balances" className="mt-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Leave Balances</CardTitle>
                  <CardDescription>View staff leave entitlements and usage</CardDescription>
                </div>
                <div className="relative w-[250px]">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search staff..."
                    value={staffSearch}
                    onChange={(e) => setStaffSearch(e.target.value)}
                    className="pl-9"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredBalances.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Staff</TableHead>
                        <TableHead>Leave Type</TableHead>
                        <TableHead className="text-center">Entitled</TableHead>
                        <TableHead className="text-center">Used</TableHead>
                        <TableHead className="text-center">Remaining</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredBalances.map((balance) => (
                        <TableRow key={balance.id}>
                          <TableCell className="font-medium">{balance.staff_name || "Unknown"}</TableCell>
                          <TableCell>{balance.leave_type_name || "Leave"}</TableCell>
                          <TableCell className="text-center">{balance.entitled_days}</TableCell>
                          <TableCell className="text-center">{balance.used_days}</TableCell>
                          <TableCell className="text-center">
                            <Badge variant={balance.remaining_days > 0 ? "default" : "destructive"}>
                              {balance.remaining_days}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Users className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="font-semibold text-lg">No Leave Balances</h3>
                  <p className="text-muted-foreground mt-1">Initialize leave balances from HR Management to see them here</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showLeaveDialog} onOpenChange={setShowLeaveDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Request Leave</DialogTitle>
            <DialogDescription>Submit a leave request for a staff member</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Staff Member</Label>
              <Select value={leaveForm.staff_id} onValueChange={(v) => setLeaveForm({ ...leaveForm, staff_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select staff member" />
                </SelectTrigger>
                <SelectContent>
                  {filteredStaff.map((staff) => (
                    <SelectItem key={staff.id} value={staff.id}>
                      {staff.first_name} {staff.last_name} ({staff.staff_number})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Leave Type</Label>
              <Select value={leaveForm.leave_type_id} onValueChange={(v) => setLeaveForm({ ...leaveForm, leave_type_id: v })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select leave type" />
                </SelectTrigger>
                <SelectContent>
                  {leaveTypes?.map((type) => (
                    <SelectItem key={type.id} value={type.id}>{type.name} ({type.days_per_year} days/year)</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Start Date</Label>
                <Input 
                  type="date" 
                  value={leaveForm.start_date} 
                  onChange={(e) => handleDateChange("start_date", e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label>End Date</Label>
                <Input 
                  type="date" 
                  value={leaveForm.end_date} 
                  onChange={(e) => handleDateChange("end_date", e.target.value)} 
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Days Requested</Label>
              <Input 
                type="number" 
                value={leaveForm.days_requested} 
                onChange={(e) => setLeaveForm({ ...leaveForm, days_requested: e.target.value })}
                placeholder="Auto-calculated from dates"
              />
            </div>
            <div className="space-y-2">
              <Label>Reason (Optional)</Label>
              <Textarea 
                value={leaveForm.reason} 
                onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })} 
                placeholder="Reason for leave..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowLeaveDialog(false)}>Cancel</Button>
            <Button 
              onClick={() => createLeaveRequest.mutate()} 
              disabled={createLeaveRequest.isPending || !leaveForm.staff_id || !leaveForm.leave_type_id || !leaveForm.start_date || !leaveForm.end_date}
            >
              Submit Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
