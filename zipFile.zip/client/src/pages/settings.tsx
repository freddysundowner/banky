import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Loader2, Save, Building2, Smartphone, Users, Clock, Shield, MessageSquare, PlayCircle, RefreshCw, Mail } from "lucide-react";
import RolesManagement from "@/components/roles-management";

interface Setting {
  id: number;
  setting_key: string;
  setting_value: string;
  setting_type: string;
  description: string;
}

interface SettingsPageProps {
  organizationId: string;
}

interface RoleCardProps {
  title: string;
  description: string;
  permissions: string[];
  badge: string;
}

function RoleCard({ title, description, permissions, badge }: RoleCardProps) {
  const badgeColors: Record<string, string> = {
    "Full Access": "bg-green-100 text-green-800",
    "High Access": "bg-blue-100 text-blue-800",
    "Standard Access": "bg-purple-100 text-purple-800",
    "Limited Access": "bg-yellow-100 text-yellow-800",
    "Read Only": "bg-gray-100 text-gray-800",
    "Basic Access": "bg-slate-100 text-slate-800",
  };

  return (
    <div className="border rounded-lg p-4">
      <div className="flex items-center justify-between mb-2">
        <h4 className="font-semibold">{title}</h4>
        <span className={`text-xs px-2 py-1 rounded-full ${badgeColors[badge] || "bg-gray-100"}`}>
          {badge}
        </span>
      </div>
      <p className="text-sm text-muted-foreground mb-3">{description}</p>
      <ul className="text-sm space-y-1">
        {permissions.map((perm, idx) => (
          <li key={idx} className="flex items-center gap-2">
            <Shield className="h-3 w-3 text-muted-foreground" />
            {perm}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function SettingsPage({ organizationId }: SettingsPageProps) {
  const { toast } = useToast();
  const [settings, setSettings] = useState<Record<string, string>>({});
  const [hasChanges, setHasChanges] = useState(false);

  const { data: settingsData, isLoading } = useQuery<Setting[]>({
    queryKey: ["/api/organizations", organizationId, "settings"],
    enabled: !!organizationId,
  });

  const updateMutation = useMutation({
    mutationFn: async (updates: Record<string, string>) => {
      return apiRequest("PUT", `/api/organizations/${organizationId}/settings`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/organizations", organizationId, "settings"] });
      toast({ title: "Settings saved successfully" });
      setHasChanges(false);
    },
    onError: () => {
      toast({ title: "Failed to save settings", variant: "destructive" });
    },
  });

  const getValue = (key: string): string => {
    if (settings[key] !== undefined) return settings[key];
    const setting = settingsData?.find(s => s.setting_key === key);
    return setting?.setting_value || "";
  };

  const getBoolValue = (key: string): boolean => {
    const value = getValue(key);
    return value.toLowerCase() === "true";
  };

  const updateSetting = (key: string, value: string) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    setHasChanges(true);
  };

  const handleSave = () => {
    updateMutation.mutate(settings);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <PageHeader
        title="Organization Settings"
        description="Configure your organization's preferences and integrations"
      />

      <div className="flex-1 overflow-auto p-4 md:p-6">
        <Tabs defaultValue="general" className="space-y-6">
          <div className="border-b">
            <div className="overflow-x-auto -mx-4 px-4 md:mx-0 md:px-0">
              <TabsList className="inline-flex h-12 items-center justify-start rounded-none bg-transparent p-0 w-auto">
                <TabsTrigger value="general" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-general">
                  <Building2 className="h-4 w-4" />
                  <span className="hidden sm:inline">General</span>
                </TabsTrigger>
                <TabsTrigger value="members" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-members">
                  <Users className="h-4 w-4" />
                  <span className="hidden sm:inline">Members</span>
                </TabsTrigger>
                <TabsTrigger value="sms" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-sms">
                  <MessageSquare className="h-4 w-4" />
                  <span className="hidden sm:inline">SMS</span>
                </TabsTrigger>
                <TabsTrigger value="email" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-email">
                  <Mail className="h-4 w-4" />
                  <span className="hidden sm:inline">Email</span>
                </TabsTrigger>
                <TabsTrigger value="mpesa" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-mpesa">
                  <Smartphone className="h-4 w-4" />
                  <span className="hidden sm:inline">M-Pesa</span>
                </TabsTrigger>
                <TabsTrigger value="hours" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-hours">
                  <Clock className="h-4 w-4" />
                  <span className="hidden sm:inline">Hours</span>
                </TabsTrigger>
                <TabsTrigger value="roles" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-roles">
                  <Shield className="h-4 w-4" />
                  <span className="hidden sm:inline">Roles</span>
                </TabsTrigger>
                <TabsTrigger value="automation" className="relative h-12 rounded-none border-b-2 border-b-transparent bg-transparent px-4 pb-3 pt-3 font-medium text-muted-foreground shadow-none transition-none data-[state=active]:border-b-primary data-[state=active]:text-foreground data-[state=active]:shadow-none gap-2" data-testid="tab-automation">
                  <PlayCircle className="h-4 w-4" />
                  <span className="hidden sm:inline">Automation</span>
                </TabsTrigger>
              </TabsList>
            </div>
          </div>

          <TabsContent value="general" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
                <CardDescription>Basic organization configuration</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="currency">Currency</Label>
                    <Select
                      value={getValue("currency")}
                      onValueChange={(value) => updateSetting("currency", value)}
                    >
                      <SelectTrigger id="currency" data-testid="select-currency">
                        <SelectValue placeholder="Select currency" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="KES">KES - Kenyan Shilling</SelectItem>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                        <SelectItem value="UGX">UGX - Ugandan Shilling</SelectItem>
                        <SelectItem value="TZS">TZS - Tanzanian Shilling</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="date_format">Date Format</Label>
                    <Select
                      value={getValue("date_format")}
                      onValueChange={(value) => updateSetting("date_format", value)}
                    >
                      <SelectTrigger id="date_format" data-testid="select-date-format">
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select
                      value={getValue("timezone") || "Africa/Nairobi"}
                      onValueChange={(value) => updateSetting("timezone", value)}
                    >
                      <SelectTrigger id="timezone" data-testid="select-timezone">
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Africa/Nairobi">Africa/Nairobi (EAT)</SelectItem>
                        <SelectItem value="Africa/Lagos">Africa/Lagos (WAT)</SelectItem>
                        <SelectItem value="Africa/Johannesburg">Africa/Johannesburg (SAST)</SelectItem>
                        <SelectItem value="Africa/Cairo">Africa/Cairo (EET)</SelectItem>
                        <SelectItem value="Africa/Accra">Africa/Accra (GMT)</SelectItem>
                        <SelectItem value="Europe/London">Europe/London (GMT/BST)</SelectItem>
                        <SelectItem value="Europe/Paris">Europe/Paris (CET)</SelectItem>
                        <SelectItem value="America/New_York">America/New_York (EST)</SelectItem>
                        <SelectItem value="America/Los_Angeles">America/Los_Angeles (PST)</SelectItem>
                        <SelectItem value="Asia/Dubai">Asia/Dubai (GST)</SelectItem>
                        <SelectItem value="Asia/Singapore">Asia/Singapore (SGT)</SelectItem>
                        <SelectItem value="Asia/Tokyo">Asia/Tokyo (JST)</SelectItem>
                        <SelectItem value="UTC">UTC</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="auto_logout_minutes">Auto Logout (minutes)</Label>
                  <Input
                    id="auto_logout_minutes"
                    type="number"
                    value={getValue("auto_logout_minutes")}
                    onChange={(e) => updateSetting("auto_logout_minutes", e.target.value)}
                    placeholder="30"
                    data-testid="input-auto-logout"
                  />
                  <p className="text-sm text-muted-foreground">
                    Automatically log out users after this many minutes of inactivity
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Require Guarantors for Loans</Label>
                    <p className="text-sm text-muted-foreground">
                      All loan applications must have guarantors
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("require_guarantors")}
                    onCheckedChange={(checked) => updateSetting("require_guarantors", String(checked))}
                    data-testid="switch-require-guarantors"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="max_guarantor_exposure">Max Guarantor Exposure</Label>
                  <Input
                    id="max_guarantor_exposure"
                    type="number"
                    value={getValue("max_guarantor_exposure")}
                    onChange={(e) => updateSetting("max_guarantor_exposure", e.target.value)}
                    placeholder="3"
                    data-testid="input-max-guarantor"
                  />
                  <p className="text-sm text-muted-foreground">
                    Maximum number of loans a member can guarantee at once
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="members" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Member Account Settings</CardTitle>
                <CardDescription>Configure member registration and activation rules</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Require Opening Deposit</Label>
                    <p className="text-sm text-muted-foreground">
                      Members must make a deposit before account activation
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("require_opening_deposit")}
                    onCheckedChange={(checked) => updateSetting("require_opening_deposit", String(checked))}
                    data-testid="switch-require-opening-deposit"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minimum_opening_deposit">Minimum Opening Deposit</Label>
                  <Input
                    id="minimum_opening_deposit"
                    type="number"
                    value={getValue("minimum_opening_deposit")}
                    onChange={(e) => updateSetting("minimum_opening_deposit", e.target.value)}
                    placeholder="0"
                    data-testid="input-min-opening-deposit"
                  />
                  <p className="text-sm text-muted-foreground">
                    Minimum amount required for account activation (when enabled)
                  </p>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Auto-Activate on First Deposit</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically activate pending accounts when they receive their first deposit
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("auto_activate_on_deposit")}
                    onCheckedChange={(checked) => updateSetting("auto_activate_on_deposit", String(checked))}
                    data-testid="switch-auto-activate"
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sms" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>SMS Integration</CardTitle>
                <CardDescription>Configure SMS notifications for members and staff</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable SMS Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send SMS alerts for loan approvals, repayment reminders, etc.
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("sms_enabled")}
                    onCheckedChange={(checked) => updateSetting("sms_enabled", String(checked))}
                    data-testid="switch-sms-enabled"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sms_sender_id">Sender ID / Short Code</Label>
                  <Input
                    id="sms_sender_id"
                    value={getValue("sms_sender_id")}
                    onChange={(e) => updateSetting("sms_sender_id", e.target.value)}
                    placeholder="e.g., PointifyPOS"
                    data-testid="input-sms-sender-id"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sms_endpoint">API Endpoint URL</Label>
                  <Input
                    id="sms_endpoint"
                    value={getValue("sms_endpoint")}
                    onChange={(e) => updateSetting("sms_endpoint", e.target.value)}
                    placeholder="https://api.smsprovider.com/send"
                    data-testid="input-sms-endpoint"
                  />
                  <p className="text-xs text-muted-foreground">
                    The full URL for sending SMS via your provider's API
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="sms_api_key">API Key</Label>
                  <Input
                    id="sms_api_key"
                    type="password"
                    value={getValue("sms_api_key")}
                    onChange={(e) => updateSetting("sms_api_key", e.target.value)}
                    placeholder="Enter your SMS API key"
                    data-testid="input-sms-api-key"
                  />
                  <p className="text-xs text-muted-foreground">
                    Your SMS provider's API key for authentication
                  </p>
                </div>

                {hasChanges && (
                  <Button onClick={handleSave} disabled={updateMutation.isPending} data-testid="button-save-sms">
                    {updateMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Save SMS Settings
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="email" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Email Settings</CardTitle>
                <CardDescription>Configure email notifications via Brevo</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Email Notifications</Label>
                    <p className="text-sm text-muted-foreground">
                      Send email notifications for payslips, reminders, etc.
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("email_enabled")}
                    onCheckedChange={(checked) => updateSetting("email_enabled", String(checked))}
                    data-testid="switch-email-enabled"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="brevo_api_key">Brevo API Key</Label>
                  <Input
                    id="brevo_api_key"
                    type="password"
                    value={getValue("brevo_api_key")}
                    onChange={(e) => updateSetting("brevo_api_key", e.target.value)}
                    placeholder="Your Brevo API key"
                    data-testid="input-brevo-api-key"
                  />
                  <p className="text-xs text-muted-foreground">
                    Get your API key from <a href="https://app.brevo.com/settings/keys/api" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">Brevo Dashboard</a>
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email_from_name">Sender Name</Label>
                  <Input
                    id="email_from_name"
                    value={getValue("email_from_name")}
                    onChange={(e) => updateSetting("email_from_name", e.target.value)}
                    placeholder="e.g., Your Organization Name"
                    data-testid="input-email-from-name"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email_from_address">Sender Email Address</Label>
                  <Input
                    id="email_from_address"
                    type="email"
                    value={getValue("email_from_address")}
                    onChange={(e) => updateSetting("email_from_address", e.target.value)}
                    placeholder="e.g., noreply@yourorganization.com"
                    data-testid="input-email-from-address"
                  />
                  <p className="text-xs text-muted-foreground">
                    This email must be verified in your Brevo account
                  </p>
                </div>

                {hasChanges && (
                  <Button 
                    onClick={handleSave} 
                    disabled={updateMutation.isPending}
                    className="w-full"
                    data-testid="button-save-email-settings"
                  >
                    {updateMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="mr-2 h-4 w-4" />
                        Save Email Settings
                      </>
                    )}
                  </Button>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="mpesa" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>M-Pesa Integration</CardTitle>
                <CardDescription>Configure M-Pesa payment gateway for member deposits</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable M-Pesa</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow members to deposit via M-Pesa
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("mpesa_enabled")}
                    onCheckedChange={(checked) => updateSetting("mpesa_enabled", String(checked))}
                    data-testid="switch-mpesa-enabled"
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="mpesa_paybill">Paybill Number</Label>
                    <Input
                      id="mpesa_paybill"
                      value={getValue("mpesa_paybill")}
                      onChange={(e) => updateSetting("mpesa_paybill", e.target.value)}
                      placeholder="e.g., 174379"
                      data-testid="input-mpesa-paybill"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="mpesa_environment">Environment</Label>
                    <Select
                      value={getValue("mpesa_environment") || "sandbox"}
                      onValueChange={(value) => updateSetting("mpesa_environment", value)}
                    >
                      <SelectTrigger id="mpesa_environment" data-testid="select-mpesa-env">
                        <SelectValue placeholder="Select environment" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="sandbox">Sandbox (Testing)</SelectItem>
                        <SelectItem value="production">Production (Live)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mpesa_consumer_key">Consumer Key</Label>
                  <Input
                    id="mpesa_consumer_key"
                    type="password"
                    value={getValue("mpesa_consumer_key")}
                    onChange={(e) => updateSetting("mpesa_consumer_key", e.target.value)}
                    placeholder="Daraja API consumer key"
                    data-testid="input-mpesa-consumer-key"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mpesa_consumer_secret">Consumer Secret</Label>
                  <Input
                    id="mpesa_consumer_secret"
                    type="password"
                    value={getValue("mpesa_consumer_secret")}
                    onChange={(e) => updateSetting("mpesa_consumer_secret", e.target.value)}
                    placeholder="Daraja API consumer secret"
                    data-testid="input-mpesa-consumer-secret"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="mpesa_passkey">Online Passkey</Label>
                  <Input
                    id="mpesa_passkey"
                    type="password"
                    value={getValue("mpesa_passkey")}
                    onChange={(e) => updateSetting("mpesa_passkey", e.target.value)}
                    placeholder="M-Pesa online passkey"
                    data-testid="input-mpesa-passkey"
                  />
                </div>

                <div className="rounded-lg bg-muted p-4">
                  <h4 className="font-medium mb-2">Callback URLs</h4>
                  <p className="text-sm text-muted-foreground mb-2">
                    Register these URLs in your Safaricom Daraja Portal:
                  </p>
                  <div className="space-y-1 text-sm font-mono bg-background p-2 rounded">
                    <p><span className="text-muted-foreground">Validation:</span> /api/mpesa/c2b/validation/{organizationId}</p>
                    <p><span className="text-muted-foreground">Confirmation:</span> /api/mpesa/c2b/confirmation/{organizationId}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="hours" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Working Hours</CardTitle>
                <CardDescription>Configure organization operating hours</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enforce Working Hours</Label>
                    <p className="text-sm text-muted-foreground">
                      Restrict system access to working hours only
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("enforce_working_hours")}
                    onCheckedChange={(checked) => updateSetting("enforce_working_hours", String(checked))}
                    data-testid="switch-enforce-hours"
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Allow Weekend Access</Label>
                    <p className="text-sm text-muted-foreground">
                      Allow staff to access the system on weekends
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("allow_weekend_access")}
                    onCheckedChange={(checked) => updateSetting("allow_weekend_access", String(checked))}
                    data-testid="switch-weekend-access"
                  />
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="working_start_time">Start Time</Label>
                    <Input
                      id="working_start_time"
                      type="time"
                      value={getValue("working_start_time") || "08:00"}
                      onChange={(e) => updateSetting("working_start_time", e.target.value)}
                      data-testid="input-start-time"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="working_end_time">End Time</Label>
                    <Input
                      id="working_end_time"
                      type="time"
                      value={getValue("working_end_time") || "17:00"}
                      onChange={(e) => updateSetting("working_end_time", e.target.value)}
                      data-testid="input-end-time"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="roles" className="space-y-4">
            <RolesManagement organizationId={organizationId} />
          </TabsContent>

          <TabsContent value="automation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Fixed Deposit Auto-Maturity</CardTitle>
                <CardDescription>Configure automatic processing of matured fixed deposits</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Auto-Maturity Processing</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically process matured fixed deposits daily at midnight
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("fd_auto_maturity_enabled")}
                    onCheckedChange={(checked) => updateSetting("fd_auto_maturity_enabled", String(checked))}
                    data-testid="switch-fd-auto-maturity"
                  />
                </div>

                <div className="rounded-lg bg-muted p-4 space-y-3">
                  <h4 className="font-medium flex items-center gap-2">
                    <RefreshCw className="h-4 w-4" />
                    How It Works
                  </h4>
                  <ul className="text-sm text-muted-foreground space-y-2 list-disc list-inside">
                    <li><strong>Regular Deposits:</strong> On maturity date, principal + interest is transferred to member's savings account</li>
                    <li><strong>Auto-Rollover Deposits:</strong> Interest is paid to savings, then a new deposit is created with the same principal for another term</li>
                    <li><strong>Processing Time:</strong> Runs daily at midnight (server timezone)</li>
                  </ul>
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Send SMS on Maturity</Label>
                    <p className="text-sm text-muted-foreground">
                      Notify members via SMS when their fixed deposit matures
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("fd_maturity_sms_enabled")}
                    onCheckedChange={(checked) => updateSetting("fd_maturity_sms_enabled", String(checked))}
                    data-testid="switch-fd-maturity-sms"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="fd_maturity_sms_template">Maturity SMS Template</Label>
                  <Input
                    id="fd_maturity_sms_template"
                    value={getValue("fd_maturity_sms_template") || "Dear {member_name}, your fixed deposit {deposit_number} has matured. Amount {amount} has been credited to your savings. Thank you for banking with us."}
                    onChange={(e) => updateSetting("fd_maturity_sms_template", e.target.value)}
                    placeholder="SMS template with {member_name}, {deposit_number}, {amount} placeholders"
                    data-testid="input-fd-maturity-sms-template"
                  />
                  <p className="text-xs text-muted-foreground">
                    Available placeholders: {"{member_name}"}, {"{deposit_number}"}, {"{amount}"}, {"{interest}"}
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Loan Reminders</CardTitle>
                <CardDescription>Configure automatic loan repayment reminders</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Enable Repayment Reminders</Label>
                    <p className="text-sm text-muted-foreground">
                      Send SMS reminders before loan repayment due dates
                    </p>
                  </div>
                  <Switch
                    checked={getBoolValue("loan_reminder_enabled")}
                    onCheckedChange={(checked) => updateSetting("loan_reminder_enabled", String(checked))}
                    data-testid="switch-loan-reminder"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="loan_reminder_days">Days Before Due Date</Label>
                  <Input
                    id="loan_reminder_days"
                    type="number"
                    value={getValue("loan_reminder_days") || "3"}
                    onChange={(e) => updateSetting("loan_reminder_days", e.target.value)}
                    placeholder="3"
                    data-testid="input-loan-reminder-days"
                  />
                  <p className="text-sm text-muted-foreground">
                    Send reminder this many days before the repayment is due
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 z-50">
          <Button
            onClick={handleSave}
            disabled={!hasChanges || updateMutation.isPending}
            size="lg"
            className="shadow-lg"
            data-testid="button-save-settings"
          >
            {updateMutation.isPending ? (
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            ) : (
              <Save className="mr-2 h-4 w-4" />
            )}
            {hasChanges ? "Save Changes" : "Saved"}
          </Button>
        </div>
      </div>
    </div>
  );
}
