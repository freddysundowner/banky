import { spawn, execSync } from "child_process";

console.log("Building frontend...");
execSync("npm run build", { stdio: "inherit" });

console.log("Starting Python backend...");
const py = spawn("python", ["-m", "uvicorn", "main:app", "--host", "0.0.0.0", "--port", "5000", "--reload"], {
  cwd: `${process.cwd()}/python_backend`,
  stdio: "inherit",
  env: process.env
});

py.on("error", (e) => { console.error(e); process.exit(1); });
py.on("close", (c) => process.exit(c || 0));
process.on("SIGTERM", () => py.kill("SIGTERM"));
process.on("SIGINT", () => py.kill("SIGINT"));
