package com.banky.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
