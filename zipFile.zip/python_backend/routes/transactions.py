from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, and_
from typing import List
from decimal import Decimal
from datetime import date
from models.database import get_db
from models.tenant import Member, Transaction, OrganizationSettings, Staff, AuditLog, TellerFloat, FloatTransaction
from schemas.tenant import TransactionCreate, TransactionResponse
from routes.auth import get_current_user
from routes.common import get_tenant_session_context, require_permission
import logging

gl_logger = logging.getLogger("accounting.gl")

def post_transaction_to_gl(tenant_session, transaction, member, staff_id=None):
    """Post a transaction to the General Ledger (fail silently if GL not available)"""
    try:
        from accounting.service import AccountingService, post_member_deposit, post_member_withdrawal
        
        svc = AccountingService(tenant_session)
        svc.seed_default_accounts()
        
        amount = Decimal(str(transaction.amount))
        member_name = f"{member.first_name} {member.last_name}"
        
        if transaction.transaction_type == "deposit":
            post_member_deposit(
                svc,
                member_id=member.id,
                amount=amount,
                account_type=transaction.account_type,
                payment_method=transaction.payment_method or "cash",
                transaction_id=str(transaction.id),
                description=f"Deposit - {member_name} - {transaction.account_type.title()}",
                created_by_id=staff_id
            )
            gl_logger.info(f"Posted deposit to GL: {transaction.transaction_number}")
        elif transaction.transaction_type == "withdrawal":
            post_member_withdrawal(
                svc,
                member_id=member.id,
                amount=amount,
                account_type=transaction.account_type,
                payment_method=transaction.payment_method or "cash",
                transaction_id=str(transaction.id),
                description=f"Withdrawal - {member_name} - {transaction.account_type.title()}",
                created_by_id=staff_id
            )
            gl_logger.info(f"Posted withdrawal to GL: {transaction.transaction_number}")
    except Exception as e:
        gl_logger.warning(f"Failed to post transaction {transaction.transaction_number} to GL: {e}")

def try_send_sms(tenant_session, template_type: str, phone: str, name: str, context: dict, member_id=None, loan_id=None):
    """Try to send SMS, fail silently if SMS not configured"""
    try:
        from routes.sms import send_sms_with_template
        if phone:
            send_sms_with_template(tenant_session, template_type, phone, name, context, member_id=member_id, loan_id=loan_id)
    except Exception as e:
        print(f"[SMS] Failed to send {template_type}: {e}")

def create_audit_log(tenant_session, staff_id, action, entity_type, entity_id, old_values=None, new_values=None):
    audit_log = AuditLog(
        staff_id=staff_id,
        action=action,
        entity_type=entity_type,
        entity_id=entity_id,
        old_values=old_values,
        new_values=new_values
    )
    tenant_session.add(audit_log)

def check_teller_float_balance(tenant_session, staff_id: str, amount: Decimal, payment_method: str) -> tuple[bool, str]:
    """Check if teller has sufficient float balance for cash withdrawal"""
    if payment_method != "cash":
        return True, ""
    
    today = date.today()
    teller_float = tenant_session.query(TellerFloat).filter(
        and_(
            TellerFloat.staff_id == staff_id,
            TellerFloat.date == today,
            TellerFloat.status == "open"
        )
    ).first()
    
    if not teller_float:
        return False, "No cash float allocated for today. Please request a cash float from your supervisor."
    
    current_balance = Decimal(str(teller_float.current_balance or 0))
    if amount > current_balance:
        return False, f"Insufficient cash float balance. Available: {float(current_balance)}, Required: {float(amount)}"
    
    return True, ""

def update_teller_float(tenant_session, staff_id: str, transaction_type: str, amount: Decimal, payment_method: str):
    """Update teller float for cash transactions"""
    import logging
    logger = logging.getLogger(__name__)
    
    logger.info(f"update_teller_float called: staff_id={staff_id}, type={transaction_type}, amount={amount}, payment={payment_method}")
    
    if payment_method != "cash":
        logger.info("Skipping - not a cash transaction")
        return
    
    today = date.today()
    teller_float = tenant_session.query(TellerFloat).filter(
        and_(
            TellerFloat.staff_id == staff_id,
            TellerFloat.date == today,
            TellerFloat.status == "open"
        )
    ).first()
    
    if not teller_float:
        logger.warning(f"No open float found for staff {staff_id} on {today}")
        return
    
    logger.info(f"Found float {teller_float.id}, current_balance={teller_float.current_balance}")
    
    current_balance = Decimal(str(teller_float.current_balance or 0))
    
    if transaction_type == "deposit":
        new_balance = current_balance + amount
        teller_float.current_balance = new_balance
        teller_float.deposits_in = Decimal(str(teller_float.deposits_in or 0)) + amount
    elif transaction_type == "withdrawal":
        new_balance = current_balance - amount
        teller_float.current_balance = new_balance
        teller_float.withdrawals_out = Decimal(str(teller_float.withdrawals_out or 0)) + amount
    else:
        return
    
    float_txn = FloatTransaction(
        teller_float_id=teller_float.id,
        transaction_type=f"member_{transaction_type}",
        amount=amount,
        balance_after=new_balance,
        description=f"Member {transaction_type}",
        performed_by_id=staff_id,
        status="completed"
    )
    tenant_session.add(float_txn)

router = APIRouter()

def get_org_setting(tenant_session, key: str, default=None):
    """Get organization setting value"""
    setting = tenant_session.query(OrganizationSettings).filter(
        OrganizationSettings.setting_key == key
    ).first()
    if setting:
        if setting.setting_type == "boolean":
            return setting.setting_value.lower() == "true"
        elif setting.setting_type == "number":
            return Decimal(setting.setting_value) if setting.setting_value else default
        return setting.setting_value
    return default

@router.get("/{org_id}/transactions")
async def list_transactions(org_id: str, member_id: str = None, account_type: str = None, today: bool = False, teller_id: str = None, branch_id: str = None, user=Depends(get_current_user), db: Session = Depends(get_db)):
    from routes.common import get_branch_filter
    
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "transactions:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        query = tenant_session.query(Transaction)
        
        # Get branch filter based on user role
        staff_branch_id = get_branch_filter(user)
        
        # If staff has branch restriction, filter by member's branch
        if staff_branch_id:
            branch_member_ids = [m.id for m in tenant_session.query(Member).filter(Member.branch_id == staff_branch_id).all()]
            query = query.filter(Transaction.member_id.in_(branch_member_ids))
        elif branch_id:
            branch_member_ids = [m.id for m in tenant_session.query(Member).filter(Member.branch_id == branch_id).all()]
            query = query.filter(Transaction.member_id.in_(branch_member_ids))
        
        if member_id:
            query = query.filter(Transaction.member_id == member_id)
        if account_type:
            query = query.filter(Transaction.account_type == account_type)
        if today:
            from datetime import datetime
            today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
            query = query.filter(Transaction.created_at >= today_start)
            
            if teller_id:
                query = query.filter(Transaction.processed_by_id == teller_id)
        elif teller_id:
            query = query.filter(Transaction.processed_by_id == teller_id)
        transactions = query.order_by(Transaction.created_at.desc()).all()
        return [TransactionResponse.model_validate(t) for t in transactions]
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.post("/{org_id}/transactions")
async def create_transaction(org_id: str, data: TransactionCreate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "transactions:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        member = tenant_session.query(Member).filter(Member.id == data.member_id).first()
        if not member:
            raise HTTPException(status_code=404, detail="Member not found")
        
        if data.account_type not in ["savings", "shares", "deposits"]:
            raise HTTPException(status_code=400, detail="Invalid account type")
        
        if data.transaction_type not in ["deposit", "withdrawal", "transfer", "fee", "interest"]:
            raise HTTPException(status_code=400, detail="Invalid transaction type")
        
        if member.status == "suspended":
            raise HTTPException(status_code=400, detail="Member account is suspended")
        
        if member.status != "active" and data.transaction_type == "withdrawal":
            raise HTTPException(status_code=400, detail="Cannot withdraw from inactive account. Activate account first.")
        
        staff = tenant_session.query(Staff).filter(Staff.email == user.email).first()
        processed_by_id = staff.id if staff else None
        
        teller_for_float = processed_by_id
        if data.teller_id:
            teller_staff = tenant_session.query(Staff).filter(Staff.id == data.teller_id).first()
            if not teller_staff:
                raise HTTPException(status_code=400, detail="Selected teller not found")
            teller_for_float = data.teller_id
        
        # Check if teller has an open float - required for ALL transactions (teller must be "on duty")
        if data.transaction_type in ["deposit", "withdrawal"]:
            if not teller_for_float:
                raise HTTPException(status_code=400, detail="Transactions require a teller with an active float")
            
            # Check if teller has an open float (meaning they're on duty)
            today = date.today()
            teller_float = tenant_session.query(TellerFloat).filter(
                and_(
                    TellerFloat.staff_id == teller_for_float,
                    TellerFloat.date == today,
                    TellerFloat.status == "open"
                )
            ).first()
            
            if not teller_float:
                raise HTTPException(status_code=400, detail="Your teller station is closed for the day. You cannot process transactions until a new float is allocated.")
            
            # For cash withdrawals, also check sufficient balance
            if data.transaction_type == "withdrawal" and data.payment_method == "cash":
                current_float_balance = Decimal(str(teller_float.current_balance or 0))
                if data.amount > current_float_balance:
                    raise HTTPException(status_code=400, detail=f"Insufficient cash float balance. Available: {float(current_float_balance)}, Required: {float(data.amount)}")
        
        balance_field = f"{data.account_type}_balance"
        current_balance = getattr(member, balance_field) or Decimal("0")
        
        if data.transaction_type == "withdrawal" and current_balance < data.amount:
            raise HTTPException(status_code=400, detail="Insufficient balance")
        
        if data.transaction_type in ["deposit", "interest"]:
            new_balance = current_balance + data.amount
        else:
            new_balance = current_balance - data.amount
        
        count = tenant_session.query(func.count(Transaction.id)).scalar() or 0
        code = f"TXN{count + 1:04d}"
        
        effective_processor_id = teller_for_float if teller_for_float else processed_by_id
        
        transaction = Transaction(
            transaction_number=code,
            member_id=data.member_id,
            transaction_type=data.transaction_type,
            account_type=data.account_type,
            amount=data.amount,
            balance_before=current_balance,
            balance_after=new_balance,
            payment_method=data.payment_method,
            reference=data.reference,
            description=data.description,
            processed_by_id=effective_processor_id
        )
        
        setattr(member, balance_field, new_balance)
        
        member_activated = False
        if member.status == "pending" and data.transaction_type == "deposit":
            auto_activate = get_org_setting(tenant_session, "auto_activate_on_deposit", True)
            require_opening_deposit = get_org_setting(tenant_session, "require_opening_deposit", False)
            min_opening_deposit = get_org_setting(tenant_session, "minimum_opening_deposit", Decimal("0"))
            
            if auto_activate:
                total_deposits = (member.savings_balance or Decimal("0")) + \
                               (member.shares_balance or Decimal("0")) + \
                               (member.deposits_balance or Decimal("0"))
                
                if not require_opening_deposit or total_deposits >= min_opening_deposit:
                    member.status = "active"
                    member_activated = True
        
        tenant_session.add(transaction)
        
        # Update teller float for cash transactions
        import logging
        tx_logger = logging.getLogger(__name__)
        tx_logger.info(f"Transaction created: type={data.transaction_type}, amount={data.amount}, payment={data.payment_method}, teller_for_float={teller_for_float}")
        
        if teller_for_float and data.payment_method == "cash":
            tx_logger.info(f"Calling update_teller_float for teller {teller_for_float}")
            update_teller_float(
                tenant_session, 
                teller_for_float, 
                data.transaction_type, 
                data.amount, 
                data.payment_method
            )
        else:
            tx_logger.warning(f"Float NOT updated: teller_for_float={teller_for_float}, payment_method={data.payment_method}")
        
        # Get new balance for audit
        new_balance = Decimal("0")
        if data.account_type == "savings":
            new_balance = member.savings_balance or Decimal("0")
        elif data.account_type == "shares":
            new_balance = member.shares_balance or Decimal("0")
        elif data.account_type == "deposits":
            new_balance = member.deposits_balance or Decimal("0")
        
        # Create audit log - record both effective processor and admin if applicable
        audit_values = {
            "member_id": data.member_id,
            "member_name": f"{member.first_name} {member.last_name}",
            "member_number": member.member_number,
            "amount": float(data.amount),
            "account_type": data.account_type,
            "transaction_type": data.transaction_type,
            "payment_method": data.payment_method,
            "transaction_code": code,
            "new_balance": float(new_balance),
            "processed_by": effective_processor_id
        }
        if data.teller_id and processed_by_id != effective_processor_id:
            audit_values["initiated_by_admin"] = processed_by_id
            audit_values["operating_as_teller"] = data.teller_id
        
        create_audit_log(
            tenant_session,
            staff_id=effective_processor_id,
            action=f"{data.transaction_type}_{data.account_type}",
            entity_type="transaction",
            entity_id=str(transaction.id) if transaction.id else code,
            new_values=audit_values
        )
        
        tenant_session.commit()
        tenant_session.refresh(transaction)
        
        # Post to General Ledger
        if data.transaction_type in ["deposit", "withdrawal"]:
            post_transaction_to_gl(tenant_session, transaction, member, staff_id=effective_processor_id)
        
        # Send SMS notification for deposit/withdrawal
        if member.phone and data.transaction_type in ["deposit", "withdrawal"]:
            sms_template = "deposit_received" if data.transaction_type == "deposit" else "withdrawal_processed"
            try_send_sms(
                tenant_session,
                sms_template,
                member.phone,
                f"{member.first_name} {member.last_name}",
                {
                    "name": member.first_name,
                    "amount": str(data.amount),
                    "balance": str(new_balance)
                },
                member_id=member.id
            )
        
        result = TransactionResponse.model_validate(transaction)
        return {
            **result.model_dump(),
            "member_activated": member_activated,
            "member_status": member.status
        }
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/transactions/{transaction_id}")
async def get_transaction(org_id: str, transaction_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "transactions:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        transaction = tenant_session.query(Transaction).filter(Transaction.id == transaction_id).first()
        if not transaction:
            raise HTTPException(status_code=404, detail="Transaction not found")
        return TransactionResponse.model_validate(transaction)
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/members/{member_id}/statement")
async def get_member_statement(org_id: str, member_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "transactions:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        member = tenant_session.query(Member).filter(Member.id == member_id).first()
        if not member:
            raise HTTPException(status_code=404, detail="Member not found")
        
        transactions = tenant_session.query(Transaction).filter(
            Transaction.member_id == member_id
        ).order_by(Transaction.created_at.desc()).all()
        
        return {
            "member": {
                "id": member.id,
                "member_number": member.member_number,
                "name": f"{member.first_name} {member.last_name}",
                "savings_balance": float(member.savings_balance or 0),
                "shares_balance": float(member.shares_balance or 0),
                "deposits_balance": float(member.deposits_balance or 0)
            },
            "transactions": [TransactionResponse.model_validate(t) for t in transactions]
        }
    finally:
        tenant_session.close()
        tenant_ctx.close()
