from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session
from sqlalchemy import func, desc
from decimal import Decimal
from datetime import datetime
import httpx
import base64
import json
from models.database import get_db
from models.tenant import Member, Transaction, OrganizationSettings, MpesaPayment, Staff
from models.master import Organization
from services.tenant_context import TenantContext
from routes.auth import get_current_user
from routes.common import get_tenant_session_context, require_permission
from services.feature_flags import check_org_feature

router = APIRouter()

def post_mpesa_deposit_to_gl(tenant_session, member, amount: Decimal, trans_id: str):
    """Post M-Pesa deposit to General Ledger"""
    try:
        from accounting.service import AccountingService, post_transaction
        
        svc = AccountingService(tenant_session)
        svc.seed_default_accounts()
        
        member_name = f"{member.first_name} {member.last_name}"
        
        post_transaction(
            svc,
            member_id=str(member.id),
            transaction_type="deposit",
            amount=amount,
            payment_method="mpesa",
            description=f"M-Pesa deposit - {member_name} - {trans_id}"
        )
        print(f"[GL] Posted M-Pesa deposit to GL: {trans_id}")
    except Exception as e:
        print(f"[GL] Failed to post M-Pesa deposit to GL: {e}")

def get_org_setting(tenant_session, key: str, default=None):
    """Get organization setting value"""
    setting = tenant_session.query(OrganizationSettings).filter(
        OrganizationSettings.setting_key == key
    ).first()
    if setting:
        if setting.setting_type == "boolean":
            return setting.setting_value.lower() == "true"
        elif setting.setting_type == "number":
            return Decimal(setting.setting_value) if setting.setting_value else default
        return setting.setting_value
    return default

@router.post("/mpesa/c2b/validation/{org_id}")
async def mpesa_validation(org_id: str, request: Request, db: Session = Depends(get_db)):
    """
    M-Pesa C2B Validation URL
    Called by Safaricom to validate a transaction before processing
    """
    try:
        data = await request.json()
        
        org = db.query(Organization).filter(Organization.id == org_id).first()
        if not org or not org.connection_string:
            return {"ResultCode": "C2B00012", "ResultDesc": "Invalid organization"}
        
        tenant_ctx = TenantContext(org.connection_string, org_id)
        tenant_session = tenant_ctx.create_session()
        
        try:
            mpesa_enabled = get_org_setting(tenant_session, "mpesa_enabled", False)
            if not mpesa_enabled:
                return {"ResultCode": "C2B00012", "ResultDesc": "M-Pesa not enabled"}
            
            account_reference = data.get("BillRefNumber", "").strip().upper()
            
            member = tenant_session.query(Member).filter(
                func.upper(Member.member_number) == account_reference
            ).first()
            
            if not member:
                return {"ResultCode": "C2B00011", "ResultDesc": "Invalid account number"}
            
            if member.status == "suspended":
                return {"ResultCode": "C2B00012", "ResultDesc": "Account suspended"}
            
            return {"ResultCode": "0", "ResultDesc": "Accepted"}
        finally:
            tenant_session.close()
            tenant_ctx.close()
            
    except Exception as e:
        return {"ResultCode": "C2B00012", "ResultDesc": str(e)}

@router.post("/mpesa/c2b/confirmation/{org_id}")
async def mpesa_confirmation(org_id: str, request: Request, db: Session = Depends(get_db)):
    """
    M-Pesa C2B Confirmation URL
    Called by Safaricom after a successful transaction
    """
    try:
        data = await request.json()
        
        org = db.query(Organization).filter(Organization.id == org_id).first()
        if not org or not org.connection_string:
            return {"ResultCode": "C2B00012", "ResultDesc": "Invalid organization"}
        
        tenant_ctx = TenantContext(org.connection_string, org_id)
        tenant_session = tenant_ctx.create_session()
        
        try:
            mpesa_enabled = get_org_setting(tenant_session, "mpesa_enabled", False)
            
            transaction_type = data.get("TransactionType", "")
            trans_id = data.get("TransID", "")
            trans_time = data.get("TransTime", "")
            amount = Decimal(str(data.get("TransAmount", 0)))
            account_reference = data.get("BillRefNumber", "").strip().upper()
            phone = data.get("MSISDN", "")
            first_name = data.get("FirstName", "")
            middle_name = data.get("MiddleName", "")
            last_name = data.get("LastName", "")
            org_balance = data.get("OrgAccountBalance")
            
            # Always log the M-Pesa payment first
            existing_mpesa = tenant_session.query(MpesaPayment).filter(
                MpesaPayment.trans_id == trans_id
            ).first()
            
            if existing_mpesa:
                return {"ResultCode": "0", "ResultDesc": "Duplicate transaction"}
            
            member = tenant_session.query(Member).filter(
                func.upper(Member.member_number) == account_reference
            ).first()
            
            # Create M-Pesa payment log
            mpesa_payment = MpesaPayment(
                trans_id=trans_id,
                trans_time=trans_time,
                amount=amount,
                phone_number=phone,
                bill_ref_number=data.get("BillRefNumber", ""),
                first_name=first_name,
                middle_name=middle_name,
                last_name=last_name,
                org_account_balance=Decimal(str(org_balance)) if org_balance else None,
                transaction_type=transaction_type,
                member_id=member.id if member else None,
                status="credited" if member and mpesa_enabled else ("unmatched" if not member else "pending"),
                raw_payload=data
            )
            tenant_session.add(mpesa_payment)
            
            if not mpesa_enabled:
                tenant_session.commit()
                return {"ResultCode": "0", "ResultDesc": "Accepted - M-Pesa disabled"}
            
            if not member:
                mpesa_payment.status = "unmatched"
                mpesa_payment.notes = f"No member found for account reference: {account_reference}"
                tenant_session.commit()
                return {"ResultCode": "0", "ResultDesc": "Accepted but member not found"}
            
            current_balance = member.savings_balance or Decimal("0")
            new_balance = current_balance + amount
            
            count = tenant_session.query(func.count(Transaction.id)).scalar() or 0
            code = f"TXN{count + 1:04d}"
            
            transaction = Transaction(
                transaction_number=code,
                member_id=member.id,
                transaction_type="deposit",
                account_type="savings",
                amount=amount,
                balance_before=current_balance,
                balance_after=new_balance,
                payment_method="mpesa",
                reference=trans_id,
                description=f"M-Pesa deposit from {phone} ({first_name})"
            )
            
            member.savings_balance = new_balance
            
            if member.status == "pending":
                auto_activate = get_org_setting(tenant_session, "auto_activate_on_deposit", True)
                require_opening_deposit = get_org_setting(tenant_session, "require_opening_deposit", False)
                min_opening_deposit = get_org_setting(tenant_session, "minimum_opening_deposit", Decimal("0"))
                
                if auto_activate:
                    total_deposits = (member.savings_balance or Decimal("0")) + \
                                   (member.shares_balance or Decimal("0")) + \
                                   (member.deposits_balance or Decimal("0"))
                    
                    if not require_opening_deposit or total_deposits >= min_opening_deposit:
                        member.status = "active"
            
            tenant_session.add(transaction)
            tenant_session.flush()
            
            # Update M-Pesa payment with transaction reference
            mpesa_payment.transaction_id = transaction.id
            mpesa_payment.status = "credited"
            mpesa_payment.credited_at = datetime.utcnow()
            
            tenant_session.commit()
            
            # Post to General Ledger
            post_mpesa_deposit_to_gl(tenant_session, member, amount, trans_id)
            
            return {"ResultCode": "0", "ResultDesc": "Accepted"}
        finally:
            tenant_session.close()
            tenant_ctx.close()
            
    except Exception as e:
        return {"ResultCode": "0", "ResultDesc": str(e)}

@router.get("/mpesa/register-urls/{org_id}")
async def get_mpesa_urls(org_id: str, request: Request):
    """
    Returns the M-Pesa callback URLs to register with Safaricom
    """
    base_url = str(request.base_url).rstrip("/")
    
    return {
        "validation_url": f"{base_url}/api/mpesa/c2b/validation/{org_id}",
        "confirmation_url": f"{base_url}/api/mpesa/c2b/confirmation/{org_id}",
        "instructions": """
To register these URLs with Safaricom:
1. Go to Safaricom Daraja Portal (https://developer.safaricom.co.ke)
2. Navigate to your app > APIs > C2B
3. Register URLs using the provided validation and confirmation URLs
4. Set Response Type to 'Completed' for both URLs
        """
    }

@router.post("/mpesa/simulate/{org_id}")
async def simulate_mpesa_deposit(
    org_id: str,
    member_number: str,
    amount: float,
    phone: str = "254712345678",
    db: Session = Depends(get_db)
):
    """
    Simulate an M-Pesa C2B deposit (for testing in sandbox)
    """
    org = db.query(Organization).filter(Organization.id == org_id).first()
    if not org or not org.connection_string:
        raise HTTPException(status_code=404, detail="Organization not found")
    
    tenant_ctx = TenantContext(org.connection_string, org_id)
    tenant_session = tenant_ctx.create_session()
    
    try:
        mpesa_enabled = get_org_setting(tenant_session, "mpesa_enabled", False)
        consumer_key = get_org_setting(tenant_session, "mpesa_consumer_key", "")
        consumer_secret = get_org_setting(tenant_session, "mpesa_consumer_secret", "")
        paybill = get_org_setting(tenant_session, "mpesa_paybill", "")
        environment = get_org_setting(tenant_session, "mpesa_environment", "sandbox")
        
        if not mpesa_enabled:
            raise HTTPException(status_code=400, detail="M-Pesa not enabled for this organization")
        
        if not consumer_key or not consumer_secret:
            raise HTTPException(status_code=400, detail="M-Pesa API credentials not configured")
        
        if environment == "sandbox":
            base_url = "https://sandbox.safaricom.co.ke"
        else:
            base_url = "https://api.safaricom.co.ke"
        
        auth_string = f"{consumer_key}:{consumer_secret}"
        auth_bytes = base64.b64encode(auth_string.encode()).decode()
        
        async with httpx.AsyncClient() as client:
            token_response = await client.get(
                f"{base_url}/oauth/v1/generate?grant_type=client_credentials",
                headers={"Authorization": f"Basic {auth_bytes}"}
            )
            
            if token_response.status_code != 200:
                raise HTTPException(status_code=400, detail="Failed to get M-Pesa access token")
            
            access_token = token_response.json().get("access_token")
            
            simulate_response = await client.post(
                f"{base_url}/mpesa/c2b/v1/simulate",
                headers={
                    "Authorization": f"Bearer {access_token}",
                    "Content-Type": "application/json"
                },
                json={
                    "ShortCode": paybill,
                    "CommandID": "CustomerPayBillOnline",
                    "Amount": int(amount),
                    "Msisdn": phone,
                    "BillRefNumber": member_number
                }
            )
            
            return simulate_response.json()
    finally:
        tenant_session.close()
        tenant_ctx.close()

# M-Pesa Payment Log Endpoints
@router.get("/organizations/{org_id}/mpesa-payments")
async def list_mpesa_payments(
    org_id: str, 
    status: str = None,
    search: str = None,
    user=Depends(get_current_user), 
    db: Session = Depends(get_db)
):
    """List all M-Pesa payments with optional filtering"""
    if not check_org_feature(org_id, "mpesa_integration", db):
        raise HTTPException(status_code=403, detail="M-Pesa integration is not available in your subscription plan")
    
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "transactions:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        query = tenant_session.query(MpesaPayment)
        
        if status:
            query = query.filter(MpesaPayment.status == status)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                (MpesaPayment.trans_id.ilike(search_term)) |
                (MpesaPayment.phone_number.ilike(search_term)) |
                (MpesaPayment.bill_ref_number.ilike(search_term)) |
                (MpesaPayment.first_name.ilike(search_term)) |
                (MpesaPayment.last_name.ilike(search_term))
            )
        
        payments = query.order_by(desc(MpesaPayment.created_at)).limit(500).all()
        
        result = []
        for p in payments:
            member_name = None
            member_number = None
            if p.member_id:
                member = tenant_session.query(Member).filter(Member.id == p.member_id).first()
                if member:
                    member_name = f"{member.first_name} {member.last_name}"
                    member_number = member.member_number
            
            result.append({
                "id": p.id,
                "trans_id": p.trans_id,
                "trans_time": p.trans_time,
                "amount": float(p.amount) if p.amount else 0,
                "phone_number": p.phone_number,
                "bill_ref_number": p.bill_ref_number,
                "sender_name": f"{p.first_name or ''} {p.middle_name or ''} {p.last_name or ''}".strip(),
                "member_id": p.member_id,
                "member_name": member_name,
                "member_number": member_number,
                "status": p.status,
                "notes": p.notes,
                "created_at": p.created_at.isoformat() if p.created_at else None
            })
        
        return result
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.post("/organizations/{org_id}/mpesa-payments/{payment_id}/credit")
async def credit_mpesa_payment(
    org_id: str,
    payment_id: str,
    member_id: str,
    account_type: str = "savings",
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    """Manually credit an unmatched M-Pesa payment to a member"""
    if not check_org_feature(org_id, "mpesa_integration", db):
        raise HTTPException(status_code=403, detail="M-Pesa integration is not available in your subscription plan")
    
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "transactions:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        payment = tenant_session.query(MpesaPayment).filter(MpesaPayment.id == payment_id).first()
        if not payment:
            raise HTTPException(status_code=404, detail="M-Pesa payment not found")
        
        if payment.status == "credited":
            raise HTTPException(status_code=400, detail="Payment already credited")
        
        member = tenant_session.query(Member).filter(Member.id == member_id).first()
        if not member:
            raise HTTPException(status_code=404, detail="Member not found")
        
        staff = tenant_session.query(Staff).filter(Staff.email == user.email).first()
        
        # Create transaction
        balance_field = f"{account_type}_balance"
        current_balance = getattr(member, balance_field) or Decimal("0")
        new_balance = current_balance + payment.amount
        
        count = tenant_session.query(func.count(Transaction.id)).scalar() or 0
        code = f"TXN{count + 1:04d}"
        
        transaction = Transaction(
            transaction_number=code,
            member_id=member.id,
            transaction_type="deposit",
            account_type=account_type,
            amount=payment.amount,
            balance_before=current_balance,
            balance_after=new_balance,
            payment_method="mpesa",
            reference=payment.trans_id,
            description=f"M-Pesa deposit (manual credit) from {payment.phone_number}",
            processed_by_id=staff.id if staff else None
        )
        
        setattr(member, balance_field, new_balance)
        tenant_session.add(transaction)
        tenant_session.flush()
        
        # Update payment record
        payment.member_id = member.id
        payment.status = "credited"
        payment.transaction_id = transaction.id
        payment.credited_by_id = staff.id if staff else None
        payment.credited_at = datetime.utcnow()
        
        tenant_session.commit()
        
        return {"success": True, "message": "Payment credited successfully", "transaction_id": transaction.id}
    finally:
        tenant_session.close()
        tenant_ctx.close()

def get_mpesa_access_token(tenant_session) -> str:
    """Get M-Pesa OAuth access token"""
    consumer_key = get_org_setting(tenant_session, "mpesa_consumer_key", "")
    consumer_secret = get_org_setting(tenant_session, "mpesa_consumer_secret", "")
    
    if not consumer_key or not consumer_secret:
        raise HTTPException(status_code=400, detail="M-Pesa credentials not configured")
    
    credentials = base64.b64encode(f"{consumer_key}:{consumer_secret}".encode()).decode()
    
    sandbox = get_org_setting(tenant_session, "mpesa_sandbox", True)
    base_url = "https://sandbox.safaricom.co.ke" if sandbox else "https://api.safaricom.co.ke"
    
    with httpx.Client(timeout=30.0) as client:
        response = client.get(
            f"{base_url}/oauth/v1/generate?grant_type=client_credentials",
            headers={"Authorization": f"Basic {credentials}"}
        )
        if response.status_code != 200:
            raise HTTPException(status_code=500, detail="Failed to get M-Pesa access token")
        return response.json().get("access_token")

def initiate_stk_push(tenant_session, phone: str, amount: Decimal, account_reference: str, description: str) -> dict:
    """Initiate M-Pesa STK Push"""
    access_token = get_mpesa_access_token(tenant_session)
    
    shortcode = get_org_setting(tenant_session, "mpesa_shortcode", "")
    passkey = get_org_setting(tenant_session, "mpesa_passkey", "")
    callback_url = get_org_setting(tenant_session, "mpesa_stk_callback_url", "")
    
    if not shortcode or not passkey:
        raise HTTPException(status_code=400, detail="M-Pesa STK Push not configured")
    
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    password = base64.b64encode(f"{shortcode}{passkey}{timestamp}".encode()).decode()
    
    # Format phone number (remove + and ensure it starts with 254)
    phone = phone.replace("+", "").replace(" ", "")
    if phone.startswith("0"):
        phone = "254" + phone[1:]
    
    sandbox = get_org_setting(tenant_session, "mpesa_sandbox", True)
    base_url = "https://sandbox.safaricom.co.ke" if sandbox else "https://api.safaricom.co.ke"
    
    payload = {
        "BusinessShortCode": shortcode,
        "Password": password,
        "Timestamp": timestamp,
        "TransactionType": "CustomerPayBillOnline",
        "Amount": int(amount),
        "PartyA": phone,
        "PartyB": shortcode,
        "PhoneNumber": phone,
        "CallBackURL": callback_url,
        "AccountReference": account_reference,
        "TransactionDesc": description
    }
    
    with httpx.Client(timeout=30.0) as client:
        response = client.post(
            f"{base_url}/mpesa/stkpush/v1/processrequest",
            json=payload,
            headers={"Authorization": f"Bearer {access_token}"}
        )
        return response.json()

@router.post("/organizations/{org_id}/mpesa/stk-push")
async def trigger_stk_push(org_id: str, request: Request, user=Depends(get_current_user), db: Session = Depends(get_db)):
    """Trigger M-Pesa STK Push for payment"""
    if not check_org_feature(org_id, "mpesa_integration", db):
        raise HTTPException(status_code=403, detail="M-Pesa integration is not available in your subscription plan")
    
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "repayments:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        data = await request.json()
        phone = data.get("phone")
        amount = Decimal(str(data.get("amount", 0)))
        account_reference = data.get("account_reference", "Payment")
        description = data.get("description", "Loan Repayment")
        
        if not phone:
            raise HTTPException(status_code=400, detail="Phone number is required")
        if amount <= 0:
            raise HTTPException(status_code=400, detail="Amount must be positive")
        
        mpesa_enabled = get_org_setting(tenant_session, "mpesa_enabled", False)
        if not mpesa_enabled:
            raise HTTPException(status_code=400, detail="M-Pesa is not enabled for this organization")
        
        result = initiate_stk_push(tenant_session, phone, amount, account_reference, description)
        
        if result.get("ResponseCode") == "0":
            return {
                "success": True,
                "message": "STK push sent successfully. Please check your phone.",
                "checkout_request_id": result.get("CheckoutRequestID"),
                "merchant_request_id": result.get("MerchantRequestID")
            }
        else:
            return {
                "success": False,
                "message": result.get("ResponseDescription", "Failed to initiate STK push"),
                "error_code": result.get("ResponseCode")
            }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        tenant_session.close()
        tenant_ctx.close()
