from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from decimal import Decimal
from datetime import datetime, timedelta, date
from models.database import get_db
from models.tenant import LoanApplication, LoanDefault, Member
from schemas.tenant import LoanDefaultResponse, LoanDefaultUpdate
from routes.auth import get_current_user
from routes.common import get_tenant_session_context, require_permission

router = APIRouter()

def post_write_off_to_gl(tenant_session, loan, amount: Decimal, reason: str):
    """Post loan write-off to General Ledger"""
    try:
        from accounting.service import AccountingService
        
        svc = AccountingService(tenant_session)
        svc.seed_default_accounts()
        
        lines = [
            {"account_code": "5030", "debit": amount, "credit": Decimal("0"), "loan_id": str(loan.id), "memo": "Bad debt expense"},
            {"account_code": "1100", "debit": Decimal("0"), "credit": amount, "loan_id": str(loan.id), "memo": "Loan written off"}
        ]
        
        svc.create_journal_entry(
            entry_date=date.today(),
            description=f"Loan write-off - {loan.application_number} - {reason}",
            source_type="loan_write_off",
            source_id=str(loan.id),
            lines=lines
        )
        print(f"[GL] Posted loan write-off to GL: {loan.application_number}")
    except Exception as e:
        print(f"[GL] Failed to post loan write-off to GL: {e}")

def check_and_create_defaults(tenant_session):
    today = date.today()
    
    overdue_loans = tenant_session.query(LoanApplication).filter(
        LoanApplication.status == "disbursed",
        LoanApplication.next_payment_date < today,
        LoanApplication.outstanding_balance > 0
    ).all()
    
    for loan in overdue_loans:
        existing_default = tenant_session.query(LoanDefault).filter(
            LoanDefault.loan_id == loan.id,
            LoanDefault.status.in_(["overdue", "in_collection"])
        ).first()
        
        if not existing_default:
            days_overdue = (today - loan.next_payment_date).days
            
            penalty_rate = Decimal("0")
            if loan.loan_product and loan.loan_product.late_payment_penalty:
                penalty_rate = loan.loan_product.late_payment_penalty
            
            penalty_amount = (loan.monthly_repayment or Decimal("0")) * penalty_rate / Decimal("100")
            
            default_record = LoanDefault(
                loan_id=loan.id,
                days_overdue=days_overdue,
                amount_overdue=loan.monthly_repayment or Decimal("0"),
                penalty_amount=penalty_amount,
                status="overdue"
            )
            tenant_session.add(default_record)
        else:
            existing_default.days_overdue = (today - loan.next_payment_date).days
    
    tenant_session.commit()

@router.get("/{org_id}/defaults")
async def list_defaults(org_id: str, status: str = None, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "defaults:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        check_and_create_defaults(tenant_session)
        
        query = tenant_session.query(LoanDefault)
        if status:
            query = query.filter(LoanDefault.status == status)
        
        defaults = query.order_by(LoanDefault.days_overdue.desc()).all()
        return [LoanDefaultResponse.model_validate(d) for d in defaults]
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/defaults/summary")
async def get_defaults_summary(org_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "defaults:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        check_and_create_defaults(tenant_session)
        
        total_overdue = tenant_session.query(func.count(LoanDefault.id)).filter(
            LoanDefault.status == "overdue"
        ).scalar() or 0
        
        total_in_collection = tenant_session.query(func.count(LoanDefault.id)).filter(
            LoanDefault.status == "in_collection"
        ).scalar() or 0
        
        total_amount_overdue = tenant_session.query(func.sum(LoanDefault.amount_overdue)).filter(
            LoanDefault.status.in_(["overdue", "in_collection"])
        ).scalar() or Decimal("0")
        
        total_penalties = tenant_session.query(func.sum(LoanDefault.penalty_amount)).filter(
            LoanDefault.status.in_(["overdue", "in_collection"])
        ).scalar() or Decimal("0")
        
        critical_defaults = tenant_session.query(func.count(LoanDefault.id)).filter(
            LoanDefault.status.in_(["overdue", "in_collection"]),
            LoanDefault.days_overdue > 90
        ).scalar() or 0
        
        return {
            "total_overdue": total_overdue,
            "total_in_collection": total_in_collection,
            "total_amount_overdue": float(total_amount_overdue),
            "total_penalties": float(total_penalties),
            "critical_defaults": critical_defaults,
            "by_age": {
                "1_30_days": tenant_session.query(func.count(LoanDefault.id)).filter(
                    LoanDefault.status.in_(["overdue", "in_collection"]),
                    LoanDefault.days_overdue.between(1, 30)
                ).scalar() or 0,
                "31_60_days": tenant_session.query(func.count(LoanDefault.id)).filter(
                    LoanDefault.status.in_(["overdue", "in_collection"]),
                    LoanDefault.days_overdue.between(31, 60)
                ).scalar() or 0,
                "61_90_days": tenant_session.query(func.count(LoanDefault.id)).filter(
                    LoanDefault.status.in_(["overdue", "in_collection"]),
                    LoanDefault.days_overdue.between(61, 90)
                ).scalar() or 0,
                "over_90_days": tenant_session.query(func.count(LoanDefault.id)).filter(
                    LoanDefault.status.in_(["overdue", "in_collection"]),
                    LoanDefault.days_overdue > 90
                ).scalar() or 0
            }
        }
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/defaults/{default_id}")
async def get_default(org_id: str, default_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "defaults:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        default = tenant_session.query(LoanDefault).filter(LoanDefault.id == default_id).first()
        if not default:
            raise HTTPException(status_code=404, detail="Default record not found")
        return LoanDefaultResponse.model_validate(default)
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.put("/{org_id}/defaults/{default_id}")
async def update_default(org_id: str, default_id: str, data: LoanDefaultUpdate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "defaults:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        default = tenant_session.query(LoanDefault).filter(LoanDefault.id == default_id).first()
        if not default:
            raise HTTPException(status_code=404, detail="Default record not found")
        
        if data.status:
            default.status = data.status
            if data.status == "resolved":
                default.resolved_at = datetime.utcnow()
        
        if data.collection_notes:
            default.collection_notes = data.collection_notes
            default.last_contact_date = datetime.utcnow()
        
        if data.next_action_date:
            default.next_action_date = data.next_action_date
        
        if data.assigned_to_id:
            default.assigned_to_id = data.assigned_to_id
        
        tenant_session.commit()
        tenant_session.refresh(default)
        return LoanDefaultResponse.model_validate(default)
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/loans/{loan_id}/defaults")
async def get_loan_defaults(org_id: str, loan_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    tenant_session = tenant_ctx.create_session()
    try:
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        defaults = tenant_session.query(LoanDefault).filter(LoanDefault.loan_id == loan_id).order_by(LoanDefault.created_at.desc()).all()
        return [LoanDefaultResponse.model_validate(d) for d in defaults]
    finally:
        tenant_session.close()
        tenant_ctx.close()

from pydantic import BaseModel

class WriteOffRequest(BaseModel):
    reason: str

@router.post("/{org_id}/defaults/{default_id}/write-off")
async def write_off_loan(org_id: str, default_id: str, data: WriteOffRequest, user=Depends(get_current_user), db: Session = Depends(get_db)):
    """Write off a defaulted loan as uncollectible"""
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "defaults:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        default = tenant_session.query(LoanDefault).filter(LoanDefault.id == default_id).first()
        if not default:
            raise HTTPException(status_code=404, detail="Default record not found")
        
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == default.loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        if loan.status == "written_off":
            raise HTTPException(status_code=400, detail="Loan has already been written off")
        
        write_off_amount = Decimal(str(loan.outstanding_balance or 0))
        
        default.status = "written_off"
        existing_notes = str(default.collection_notes or "")
        default.collection_notes = f"{existing_notes}\n[Write-off] {data.reason}".strip()
        default.resolved_at = datetime.utcnow()
        
        loan.status = "written_off"
        loan.outstanding_balance = Decimal("0")
        
        tenant_session.commit()
        
        post_write_off_to_gl(tenant_session, loan, write_off_amount, data.reason)
        
        return {
            "message": f"Loan {loan.application_number} written off successfully",
            "write_off_amount": float(write_off_amount)
        }
    finally:
        tenant_session.close()
        tenant_ctx.close()
