from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from typing import List
from decimal import Decimal
from datetime import datetime, timedelta
import logging
from models.database import get_db
from models.tenant import LoanApplication, LoanRepayment, Transaction, Member
from schemas.tenant import LoanRepaymentCreate, LoanRepaymentResponse
from routes.auth import get_current_user
from routes.common import get_tenant_session_context, require_permission

gl_logger = logging.getLogger("accounting.gl")

router = APIRouter()

def post_repayment_to_gl(tenant_session, repayment, loan, member):
    """Post a loan repayment to the General Ledger"""
    try:
        from accounting.service import AccountingService, post_loan_repayment
        
        svc = AccountingService(tenant_session)
        svc.seed_default_accounts()
        
        member_name = f"{member.first_name} {member.last_name}"
        
        print(f"[GL] Posting repayment {repayment.repayment_number}: principal={repayment.principal_amount}, interest={repayment.interest_amount}")
        
        je = post_loan_repayment(
            svc,
            member_id=str(member.id),
            loan_id=str(loan.id),
            principal_amount=repayment.principal_amount or Decimal("0"),
            interest_amount=repayment.interest_amount or Decimal("0"),
            penalty_amount=repayment.penalty_amount or Decimal("0"),
            payment_method=repayment.payment_method or "cash",
            repayment_id=str(repayment.id),
            description=f"Loan repayment - {member_name} - {loan.application_number}"
        )
        print(f"[GL] Posted repayment to GL: {repayment.repayment_number}, journal entry: {je.entry_number if je else 'None'}")
        gl_logger.info(f"Posted repayment to GL: {repayment.repayment_number}")
    except Exception as e:
        import traceback
        print(f"[GL] Failed to post repayment {repayment.repayment_number} to GL: {e}")
        traceback.print_exc()
        gl_logger.warning(f"Failed to post repayment {repayment.repayment_number} to GL: {e}")

def try_send_sms(tenant_session, template_type: str, phone: str, name: str, context: dict, member_id=None, loan_id=None):
    """Try to send SMS, fail silently if SMS not configured"""
    try:
        from routes.sms import send_sms_with_template
        if phone:
            send_sms_with_template(tenant_session, template_type, phone, name, context, member_id=member_id, loan_id=loan_id)
    except Exception as e:
        print(f"[SMS] Failed to send {template_type}: {e}")

def calculate_payment_allocation(loan: LoanApplication, amount: Decimal):
    # If interest was deducted upfront, all payments go to principal
    if getattr(loan, 'interest_deducted_upfront', False):
        principal_portion = amount
        interest_portion = Decimal("0")
        penalty_portion = Decimal("0")
    else:
        interest_rate_monthly = loan.interest_rate / Decimal("100") / Decimal("12")
        interest_portion = min(amount, (loan.outstanding_balance or Decimal("0")) * interest_rate_monthly)
        principal_portion = amount - interest_portion
        penalty_portion = Decimal("0")
    return principal_portion, interest_portion, penalty_portion

@router.get("/{org_id}/repayments")
async def list_repayments(org_id: str, loan_id: str = None, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "repayments:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        query = tenant_session.query(LoanRepayment)
        if loan_id:
            query = query.filter(LoanRepayment.loan_id == loan_id)
        repayments = query.order_by(LoanRepayment.payment_date.desc()).all()
        return [LoanRepaymentResponse.model_validate(r) for r in repayments]
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.post("/{org_id}/repayments")
async def create_repayment(org_id: str, data: LoanRepaymentCreate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "repayments:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == data.loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        if loan.status != "disbursed":
            raise HTTPException(status_code=400, detail="Loan is not active for repayment")
        
        if data.amount <= 0:
            raise HTTPException(status_code=400, detail="Amount must be positive")
        
        principal_amount, interest_amount, penalty_amount = calculate_payment_allocation(loan, data.amount)
        
        count = tenant_session.query(func.count(LoanRepayment.id)).scalar() or 0
        code = f"REP{count + 1:04d}"
        
        repayment = LoanRepayment(
            repayment_number=code,
            loan_id=data.loan_id,
            amount=data.amount,
            principal_amount=principal_amount,
            interest_amount=interest_amount,
            penalty_amount=penalty_amount,
            payment_method=data.payment_method,
            reference=data.reference,
            notes=data.notes,
            payment_date=datetime.utcnow()
        )
        
        loan.amount_repaid = (loan.amount_repaid or Decimal("0")) + data.amount
        loan.outstanding_balance = (loan.outstanding_balance or Decimal("0")) - data.amount
        loan.last_payment_date = datetime.utcnow().date()
        
        if loan.monthly_repayment:
            days_per_month = 30
            loan.next_payment_date = (datetime.utcnow() + timedelta(days=days_per_month)).date()
        
        if loan.outstanding_balance <= 0:
            loan.status = "paid"
            loan.closed_at = datetime.utcnow()
            loan.outstanding_balance = Decimal("0")
        
        txn_count = tenant_session.query(func.count(Transaction.id)).scalar() or 0
        txn_code = f"TXN{txn_count + 1:04d}"
        transaction = Transaction(
            transaction_number=txn_code,
            member_id=loan.member_id,
            transaction_type="loan_repayment",
            account_type="loan",
            amount=data.amount,
            reference=data.reference,
            description=f"Loan repayment for {loan.application_number}"
        )
        
        tenant_session.add(repayment)
        tenant_session.add(transaction)
        tenant_session.commit()
        tenant_session.refresh(repayment)
        
        # Post to General Ledger
        member = tenant_session.query(Member).filter(Member.id == loan.member_id).first()
        if member:
            post_repayment_to_gl(tenant_session, repayment, loan, member)
        
        # Send SMS notification for repayment received
        if member and member.phone:
            try_send_sms(
                tenant_session,
                "repayment_received",
                member.phone,
                f"{member.first_name} {member.last_name}",
                {
                    "name": member.first_name,
                    "amount": str(data.amount),
                    "balance": str(loan.outstanding_balance or 0)
                },
                member_id=member.id,
                loan_id=loan.id
            )
        
        return LoanRepaymentResponse.model_validate(repayment)
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/repayments/{repayment_id}")
async def get_repayment(org_id: str, repayment_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "repayments:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        repayment = tenant_session.query(LoanRepayment).filter(LoanRepayment.id == repayment_id).first()
        if not repayment:
            raise HTTPException(status_code=404, detail="Repayment not found")
        return LoanRepaymentResponse.model_validate(repayment)
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/loans/{loan_id}/schedule")
async def get_loan_schedule(org_id: str, loan_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "repayments:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        schedule = []
        balance = loan.amount
        monthly_payment = loan.monthly_repayment or Decimal("0")
        interest_rate_monthly = loan.interest_rate / Decimal("100") / Decimal("12")
        interest_deducted_upfront = getattr(loan, 'interest_deducted_upfront', False)
        
        start_date = loan.disbursed_at or loan.approved_at or loan.applied_at
        
        for i in range(loan.term_months):
            if interest_deducted_upfront:
                # All payments go to principal when interest was deducted upfront
                interest = Decimal("0")
                principal = monthly_payment
            else:
                interest = balance * interest_rate_monthly
                principal = monthly_payment - interest
            
            balance = max(Decimal("0"), balance - principal)
            
            payment_date = start_date + timedelta(days=30 * (i + 1))
            
            schedule.append({
                "installment_number": i + 1,
                "due_date": payment_date.date().isoformat(),
                "principal": float(round(principal, 2)),
                "interest": float(round(interest, 2)),
                "total_payment": float(round(monthly_payment, 2)),
                "balance_after": float(round(balance, 2))
            })
        
        return {
            "loan_id": loan.id,
            "application_number": loan.application_number,
            "amount": float(loan.amount),
            "term_months": loan.term_months,
            "interest_rate": float(loan.interest_rate),
            "monthly_payment": float(loan.monthly_repayment or 0),
            "interest_deducted_upfront": interest_deducted_upfront,
            "schedule": schedule
        }
    finally:
        tenant_session.close()
        tenant_ctx.close()
