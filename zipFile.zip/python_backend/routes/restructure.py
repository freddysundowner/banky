from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from decimal import Decimal
from datetime import datetime, timedelta, date
from models.database import get_db
from models.tenant import LoanApplication, LoanRestructure, Member
from schemas.tenant import LoanRestructureCreate, LoanRestructureResponse
from routes.auth import get_current_user
from routes.common import get_tenant_session_context, require_permission

router = APIRouter()

def post_penalty_waiver_to_gl(tenant_session, loan, waived_amount: Decimal, reason: str):
    """Post penalty waiver to General Ledger"""
    try:
        from accounting.service import AccountingService
        
        svc = AccountingService(tenant_session)
        svc.seed_default_accounts()
        
        lines = [
            {"account_code": "5040", "debit": waived_amount, "credit": Decimal("0"), "loan_id": str(loan.id), "memo": "Penalty waiver expense"},
            {"account_code": "1100", "debit": Decimal("0"), "credit": waived_amount, "loan_id": str(loan.id), "memo": "Penalty waived"}
        ]
        
        svc.create_journal_entry(
            entry_date=date.today(),
            description=f"Penalty waiver - {loan.application_number} - {reason}",
            source_type="penalty_waiver",
            source_id=str(loan.id),
            lines=lines
        )
        print(f"[GL] Posted penalty waiver to GL: {loan.application_number}")
    except Exception as e:
        print(f"[GL] Failed to post penalty waiver to GL: {e}")

def recalculate_loan(loan: LoanApplication, new_term: int = None, new_rate: Decimal = None):
    term = new_term or loan.term_months
    rate = new_rate if new_rate is not None else loan.interest_rate
    principal = loan.outstanding_balance or loan.amount
    interest_deducted_upfront = getattr(loan, 'interest_deducted_upfront', False)
    
    if interest_deducted_upfront:
        # For loans with upfront interest deduction, only principal payments remain
        monthly_payment = principal / term
        total_repayment = principal
        total_interest = Decimal("0")  # Interest was already paid upfront
    else:
        monthly_rate = rate / Decimal("100") / Decimal("12")
        
        if monthly_rate > 0:
            monthly_payment = principal * (monthly_rate * (1 + monthly_rate) ** term) / ((1 + monthly_rate) ** term - 1)
        else:
            monthly_payment = principal / term
        
        total_repayment = monthly_payment * term
        total_interest = total_repayment - principal
    
    return {
        "monthly_repayment": round(monthly_payment, 2),
        "total_repayment": round(total_repayment, 2),
        "total_interest": round(total_interest, 2)
    }

@router.get("/{org_id}/loans/{loan_id}/restructures")
async def list_loan_restructures(org_id: str, loan_id: str, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "restructure:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        restructures = tenant_session.query(LoanRestructure).filter(LoanRestructure.loan_id == loan_id).order_by(LoanRestructure.created_at.desc()).all()
        return [LoanRestructureResponse.model_validate(r) for r in restructures]
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.post("/{org_id}/loans/{loan_id}/restructure")
async def restructure_loan(org_id: str, loan_id: str, data: LoanRestructureCreate, user=Depends(get_current_user), db: Session = Depends(get_db)):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "restructure:write", db)
    tenant_session = tenant_ctx.create_session()
    try:
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        if loan.status != "disbursed":
            raise HTTPException(status_code=400, detail="Only active loans can be restructured")
        
        valid_types = ["extend_term", "reduce_installment", "adjust_interest", "waive_penalty", "grace_period"]
        if data.restructure_type not in valid_types:
            raise HTTPException(status_code=400, detail=f"Invalid restructure type")
        
        restructure = LoanRestructure(
            loan_id=loan_id,
            restructure_type=data.restructure_type,
            old_term_months=loan.term_months,
            old_interest_rate=loan.interest_rate,
            old_monthly_repayment=loan.monthly_repayment,
            reason=data.reason
        )
        
        if data.restructure_type == "extend_term" and data.new_term_months:
            if data.new_term_months <= loan.term_months:
                raise HTTPException(status_code=400, detail="New term must be greater than current term")
            
            recalc = recalculate_loan(loan, new_term=data.new_term_months)
            restructure.new_term_months = data.new_term_months
            restructure.new_monthly_repayment = recalc["monthly_repayment"]
            
            loan.term_months = data.new_term_months
            loan.monthly_repayment = recalc["monthly_repayment"]
            loan.total_repayment = recalc["total_repayment"]
            loan.total_interest = recalc["total_interest"]
        
        elif data.restructure_type == "reduce_installment" and data.new_monthly_repayment:
            if data.new_monthly_repayment >= (loan.monthly_repayment or Decimal("0")):
                raise HTTPException(status_code=400, detail="New installment must be less than current")
            
            restructure.new_monthly_repayment = data.new_monthly_repayment
            loan.monthly_repayment = data.new_monthly_repayment
            
            if loan.outstanding_balance and data.new_monthly_repayment > 0:
                new_term = int((loan.outstanding_balance / data.new_monthly_repayment) + 1)
                restructure.new_term_months = new_term
                loan.term_months = new_term
        
        elif data.restructure_type == "adjust_interest" and data.new_interest_rate is not None:
            recalc = recalculate_loan(loan, new_rate=data.new_interest_rate)
            restructure.new_interest_rate = data.new_interest_rate
            restructure.new_monthly_repayment = recalc["monthly_repayment"]
            
            loan.interest_rate = data.new_interest_rate
            loan.monthly_repayment = recalc["monthly_repayment"]
            loan.total_repayment = recalc["total_repayment"]
            loan.total_interest = recalc["total_interest"]
        
        elif data.restructure_type == "waive_penalty" and data.penalty_waived:
            restructure.penalty_waived = data.penalty_waived
            if loan.outstanding_balance:
                loan.outstanding_balance = loan.outstanding_balance - data.penalty_waived
            # Post to GL
            post_penalty_waiver_to_gl(tenant_session, loan, data.penalty_waived, data.reason or "Penalty waiver")
        
        elif data.restructure_type == "grace_period" and data.grace_period_days:
            restructure.grace_period_days = data.grace_period_days
            if loan.next_payment_date:
                loan.next_payment_date = loan.next_payment_date + timedelta(days=data.grace_period_days)
        
        loan.is_restructured = True
        
        tenant_session.add(restructure)
        tenant_session.commit()
        tenant_session.refresh(restructure)
        return LoanRestructureResponse.model_validate(restructure)
    finally:
        tenant_session.close()
        tenant_ctx.close()

@router.get("/{org_id}/loans/{loan_id}/restructure/preview")
async def preview_restructure(
    org_id: str, 
    loan_id: str, 
    restructure_type: str,
    new_term_months: int = None,
    new_interest_rate: float = None,
    new_monthly_repayment: float = None,
    user=Depends(get_current_user),
    db: Session = Depends(get_db)
):
    tenant_ctx, membership = get_tenant_session_context(org_id, user, db)
    require_permission(membership, "restructure:read", db)
    tenant_session = tenant_ctx.create_session()
    try:
        loan = tenant_session.query(LoanApplication).filter(LoanApplication.id == loan_id).first()
        if not loan:
            raise HTTPException(status_code=404, detail="Loan not found")
        
        current = {
            "term_months": loan.term_months,
            "interest_rate": float(loan.interest_rate),
            "monthly_repayment": float(loan.monthly_repayment or 0),
            "outstanding_balance": float(loan.outstanding_balance or 0)
        }
        
        new_term = new_term_months or loan.term_months
        new_rate = Decimal(str(new_interest_rate)) if new_interest_rate else loan.interest_rate
        
        recalc = recalculate_loan(loan, new_term=new_term, new_rate=new_rate)
        
        proposed = {
            "term_months": new_term,
            "interest_rate": float(new_rate),
            "monthly_repayment": float(recalc["monthly_repayment"]),
            "total_repayment": float(recalc["total_repayment"]),
            "total_interest": float(recalc["total_interest"])
        }
        
        return {
            "current": current,
            "proposed": proposed,
            "savings": {
                "monthly_savings": current["monthly_repayment"] - proposed["monthly_repayment"]
            }
        }
    finally:
        tenant_session.close()
        tenant_ctx.close()
